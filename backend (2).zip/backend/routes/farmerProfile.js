const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const auth = require('../middleware/auth');
const User = require('../models/User');

// Set up multer for profile image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/profiles';
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// @desc    Get farmer's profile
// @route   GET /api/farmer/profile
// @access  Private/Farmer
router.get('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'farmer') {
      return res.status(403).json({ message: 'Access denied. Only farmers can view their profile.' });
    }

    const user = await User.findById(req.user._id).select('farmerProfile');
    res.json(user.farmerProfile);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Create/Update farmer's profile
// @route   POST /api/farmer/profile
// @access  Private/Farmer
router.post('/', auth, upload.single('profileImage'), async (req, res) => {
  try {
    if (req.user.role !== 'farmer') {
      return res.status(403).json({ message: 'Access denied. Only farmers can update their profile.' });
    }

    // Get the profile data from request body
    const profileData = {
      farmName: req.body.farmName,
      farmSize: req.body.farmSize,
      farmLocation: req.body.farmLocation,
      cropTypes: req.body.cropTypes || [],
      experienceYears: req.body.experienceYears || 0,
      certification: req.body.certification || 'None',
      bio: req.body.bio || '',
      profileImage: req.user.farmerProfile?.profileImage || 'https://via.placeholder.com/150'
    };

    // Validate required fields
    if (!profileData.farmName || !profileData.farmSize || !profileData.farmLocation) {
      return res.status(400).json({ 
        message: 'Farm name, farm size, and farm location are required' 
      });
    }

    // Handle profile image upload if file was provided
    if (req.file) {
      // Delete old profile image if it exists and is not the default
      if (profileData.profileImage && profileData.profileImage !== 'https://via.placeholder.com/150') {
        const oldImagePath = path.join(__dirname, '../uploads/profiles', path.basename(profileData.profileImage));
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      }
      
      profileData.profileImage = `http://localhost:5001/uploads/profiles/${req.file.filename}`;
    }

    // Update user's profile
    const updatedUser = await User.findByIdAndUpdate(
      req.user._id,
      {
        farmerProfile: profileData
      },
      { new: true, runValidators: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(updatedUser.farmerProfile);
  } catch (error) {
    console.error('Profile update error:', error);
    // If validation error, return the specific error message
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: Object.values(error.errors).map(err => err.message).join(', ') });
    }
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
