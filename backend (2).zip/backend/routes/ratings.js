const express = require('express');
const router = express.Router();
const Rating = require('../models/Rating');
const Order = require('../models/Order');
const auth = require('../middleware/auth');
const multer = require('multer');
const { uploadToCloudinary } = require('../utils/cloudinary');

// Configure multer for file uploads
const upload = multer({
  limits: {
    fileSize: 5000000 // 5MB limit
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
      return cb(new Error('Please upload an image file'));
    }
    cb(null, true);
  }
});

// Submit a rating
router.post('/', auth, upload.array('photos', 3), async (req, res) => {
  try {
    const { orderId, rating, review, type } = req.body;

    // Verify order exists and user is authorized
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    // Verify user is part of the transaction
    const isAuthorized = 
      (type === 'buyer-to-farmer' && order.buyer.toString() === req.user._id.toString()) ||
      (type === 'farmer-to-buyer' && order.farmer.toString() === req.user._id.toString());

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Not authorized to rate this transaction' });
    }

    // Upload photos if provided
    const photoUrls = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        const result = await uploadToCloudinary(file.buffer);
        photoUrls.push(result.secure_url);
      }
    }

    const newRating = new Rating({
      order: orderId,
      rater: req.user._id,
      recipient: type === 'buyer-to-farmer' ? order.farmer : order.buyer,
      rating: Number(rating),
      review,
      type,
      deliveryPhotos: photoUrls
    });

    await newRating.save();
    await newRating.populate('rater recipient');
    
    res.status(201).json(newRating);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get ratings for a user
router.get('/user/:userId', async (req, res) => {
  try {
    const ratings = await Rating.find({ recipient: req.params.userId })
      .populate('rater order')
      .sort({ createdAt: -1 });
    
    const stats = await Rating.calculateAverageRating(req.params.userId);
    
    res.json({
      ratings,
      stats
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get ratings for an order
router.get('/order/:orderId', async (req, res) => {
  try {
    const ratings = await Rating.find({ order: req.params.orderId })
      .populate('rater recipient');
    res.json(ratings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
