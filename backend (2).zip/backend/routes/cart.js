const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const Product = require('../models/Product');

// Get cart items
router.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('cart.product');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const cartItems = user.cart.map(item => ({
      _id: item.product._id,
      name: item.product.name,
      description: item.product.description,
      price: item.product.price,
      imageUrl: item.product.imageUrl,
      quantity: item.quantity,
      seller: item.product.seller
    }));

    res.json({ items: cartItems });
  } catch (error) {
    console.error('Error fetching cart:', error);
    res.status(500).json({ message: 'Error fetching cart items' });
  }
});

// Add/Update cart item
router.put('/update', auth, async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    
    // Validate input
    if (!productId || !quantity) {
      return res.status(400).json({ message: 'Product ID and quantity are required' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if user is a farmer
    if (user.role === 'farmer') {
      return res.status(403).json({ message: 'Farmers cannot add items to cart' });
    }

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if product is available
    if (product.quantity < quantity) {
      return res.status(400).json({ 
        message: 'Insufficient stock',
        availableQuantity: product.quantity 
      });
    }

    // Check if product is owned by the same farmer
    if (product.seller.toString() === user._id.toString()) {
      return res.status(400).json({ message: 'Cannot add your own products to cart' });
    }

    const cartItemIndex = user.cart.findIndex(
      item => item.product.toString() === productId
    );

    if (cartItemIndex > -1) {
      // Update existing item
      user.cart[cartItemIndex].quantity = quantity;
    } else if (quantity > 0) {
      // Add new item
      user.cart.push({
        product: productId,
        quantity
      });
    }

    await user.save();
    
    // Return updated cart items
    const updatedUser = await User.findById(user._id).populate('cart.product');
    const cartItems = updatedUser.cart.map(item => ({
      _id: item.product._id,
      name: item.product.name,
      price: item.product.price,
      imageUrl: item.product.imageUrl,
      quantity: item.quantity
    }));

    res.json({ 
      message: 'Cart updated successfully',
      items: cartItems
    });
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).json({ 
      message: 'Error updating cart',
      error: error.message 
    });
  }
});

// Remove item from cart
router.delete('/remove/:productId', auth, async (req, res) => {
  try {
    const { productId } = req.params;
    if (!productId) {
      return res.status(400).json({ message: 'Product ID is required' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const cartItemIndex = user.cart.findIndex(
      item => item.product.toString() === productId
    );

    if (cartItemIndex > -1) {
      user.cart.splice(cartItemIndex, 1);
      await user.save();
      res.json({ message: 'Item removed from cart' });
    } else {
      res.status(404).json({ message: 'Item not found in cart' });
    }
  } catch (error) {
    console.error('Error removing item from cart:', error);
    res.status(500).json({ message: 'Error removing item from cart' });
  }
});

// Clear entire cart
router.delete('/clear', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.cart = [];
    await user.save();
    res.json({ message: 'Cart cleared successfully' });
  } catch (error) {
    console.error('Error clearing cart:', error);
    res.status(500).json({ message: 'Error clearing cart' });
  }
});

module.exports = router;
