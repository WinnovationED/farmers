const express = require('express');
const router = express.Router();
const Razorpay = require('razorpay');
const crypto = require('crypto');
const auth = require('../middleware/auth');
const Order = require('../models/Order');
const axios = require('axios');
const Product = require('../models/productModel'); // Updated Product model import path

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Create Razorpay order
router.post('/razorpay/order', auth, async (req, res) => {
  try {
    const { amount, orderId } = req.body;

    const options = {
      amount: amount, // Amount is already in paise from frontend
      currency: 'INR',
      receipt: 'order_' + orderId,
      payment_capture: 1
    };

    const razorpayOrder = await razorpay.orders.create(options);
    res.json({
      id: razorpayOrder.id,
      amount: razorpayOrder.amount,
      currency: razorpayOrder.currency,
      key: process.env.RAZORPAY_KEY_ID
    });
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    res.status(500).json({ message: 'Payment initialization failed' });
  }
});

// Verify payment
router.post('/razorpay/verify', auth, async (req, res) => {
  try {
    const {
      razorpayPaymentId,
      razorpayOrderId,
      razorpaySignature,
      orderId
    } = req.body;

    // Verify signature
    const sign = razorpayOrderId + '|' + razorpayPaymentId;
    const expectedSign = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(sign)
      .digest('hex');

    if (razorpaySignature !== expectedSign) {
      return res.status(400).json({ message: 'Invalid payment signature' });
    }

    // Find and update order
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Update payment details
    order.paymentDetails = {
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature
    };
    
    // Update order status to paid
    order.paymentStatus = 'completed';
    order.status = 'confirmed';
    await order.save();

    // Update product quantity
    const product = await Product.findById(order.product);
    if (!product) {
      throw new Error('Product not found');
    }

    if (product.quantity < order.quantity) {
      // If product is out of stock, refund the payment
      await razorpay.payments.refund(razorpayPaymentId);
      order.status = 'cancelled';
      order.paymentStatus = 'refunded';
      await order.save();
      return res.status(400).json({ 
        message: 'Product out of stock. Payment will be refunded.',
        availableQuantity: product.quantity 
      });
    }

    product.quantity -= order.quantity;
    await product.save();

    res.json({
      message: 'Payment verified successfully',
      order
    });
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ message: 'Payment verification failed' });
  }
});

// Get payment details
router.get('/order/:orderId', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if user is authorized to view this order
    if (order.buyer.toString() !== req.user.id && 
        order.seller.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    if (!order.paymentDetails?.razorpayOrderId) {
      return res.status(404).json({ message: 'Payment not found for this order' });
    }

    const payment = await razorpay.orders.fetch(order.paymentDetails.razorpayOrderId);
    res.json(payment);
  } catch (error) {
    console.error('Error fetching payment details:', error);
    res.status(500).json({ message: 'Failed to fetch payment details' });
  }
});

module.exports = router;
