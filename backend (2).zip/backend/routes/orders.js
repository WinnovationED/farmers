const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Order = require('../models/Order');
const Product = require('../models/productModel');

// Create new order
router.post('/', auth, async (req, res) => {
  try {
    const { productId, quantity, shippingAddress, totalAmount } = req.body;

    // Validate user is a buyer
    if (req.user.role !== 'buyer') {
      return res.status(403).json({ message: 'Only buyers can place orders' });
    }

    // Check if product exists and has enough quantity
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Don't update quantity until payment is confirmed
    if (product.quantity < quantity) {
      return res.status(400).json({ message: 'Not enough quantity available' });
    }

    // Create order with pending status
    const order = new Order({
      buyer: req.user.id,
      seller: product.seller,
      product: productId,
      quantity,
      totalAmount,
      shippingAddress,
      status: 'pending',
      paymentStatus: 'pending'
    });

    // Save order without updating product quantity yet
    await order.save();

    // Populate order details
    const populatedOrder = await Order.findById(order._id)
      .populate('product')
      .populate('seller', 'name email')
      .populate('buyer', 'name email');

    res.status(201).json(populatedOrder);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user's orders
router.get('/', auth, async (req, res) => {
  try {
    const query = req.user.role === 'buyer' 
      ? { buyer: req.user.id }
      : { seller: req.user.id };

    const orders = await Order.find(query)
      .populate('product')
      .populate('seller', 'name email')
      .populate('buyer', 'name email')
      .sort({ createdAt: -1 });

    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get order by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('product')
      .populate('seller', 'name email')
      .populate('buyer', 'name email');

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if user is buyer or seller of the order
    if (order.buyer._id.toString() !== req.user.id && 
        order.seller._id.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    res.json(order);
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update order status and quantity after payment verification
router.post('/:id/payment-success', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Verify the buyer
    if (order.buyer.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Get product and check quantity again
    const product = await Product.findById(order.product);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    if (product.quantity < order.quantity) {
      order.status = 'cancelled';
      order.paymentStatus = 'refunded';
      await order.save();
      return res.status(400).json({ message: 'Product out of stock' });
    }

    // Update product quantity
    product.quantity -= order.quantity;
    await product.save();

    // Update order status
    order.status = 'confirmed';
    order.paymentStatus = 'completed';
    await order.save();

    const updatedOrder = await Order.findById(order._id)
      .populate('product')
      .populate('seller', 'name email')
      .populate('buyer', 'name email');

    res.json(updatedOrder);
  } catch (error) {
    console.error('Error updating order after payment:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update order status (seller only)
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if user is the seller
    if (order.seller.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Only seller can update order status' });
    }

    // Update status
    order.status = status;
    await order.save();

    const updatedOrder = await Order.findById(order._id)
      .populate('product')
      .populate('seller', 'name email')
      .populate('buyer', 'name email');

    res.json(updatedOrder);
  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
