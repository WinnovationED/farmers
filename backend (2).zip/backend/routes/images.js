const express = require('express');
const router = express.Router();
const OpenAI = require('openai');
const auth = require('../middleware/auth');

// Debug: Log environment variables
console.log('Environment variables:', {
  OPENAI_API_KEY_SET: !!process.env.OPENAI_API_KEY,
  OPENAI_API_KEY_LENGTH: process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.length : 0,
  NODE_ENV: process.env.NODE_ENV
});

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Generate image using DALL-E
router.post('/generate', auth, async (req, res) => {
  try {
    // Debug: Log API key status
    console.log('OpenAI API Key status:', {
      exists: !!process.env.OPENAI_API_KEY,
      length: process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.length : 0,
      isDefault: process.env.OPENAI_API_KEY === 'sk-your-api-key-here'
    });

    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'sk-your-api-key-here') {
      return res.status(500).json({ 
        message: 'OpenAI API key not configured. Please add your API key to the .env file.',
        details: 'Get your API key from https://platform.openai.com/api-keys'
      });
    }

    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).json({ message: 'Prompt is required' });
    }

    console.log('Generating image with prompt:', prompt);

    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
      response_format: "url"
    });

    console.log('Image generated successfully');
    res.json({ imageUrl: response.data[0].url });
  } catch (error) {
    console.error('Error generating image:', error);

    // Check for specific OpenAI errors
    if (error.response?.data?.error?.message) {
      return res.status(400).json({ 
        message: error.response.data.error.message,
        type: 'openai_error'
      });
    }

    // Check for authentication errors
    if (error.message.includes('authentication')) {
      return res.status(500).json({ 
        message: 'Invalid OpenAI API key. Please check your API key in the .env file.',
        type: 'auth_error'
      });
    }

    res.status(500).json({ 
      message: error.message || 'Failed to generate image',
      type: 'general_error'
    });
  }
});

module.exports = router;
