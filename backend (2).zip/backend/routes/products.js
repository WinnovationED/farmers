const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const auth = require('../middleware/auth');
const Product = require('../models/productModel');

// Farmer authentication middleware
const farmerAuth = (req, res, next) => {
  if (!req.user || req.user.role !== 'farmer') {
    return res.status(403).json({ message: 'Access denied. Only farmers can perform this action.' });
  }
  next();
};

// Set up multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/products';
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// @desc    Get all products
// @route   GET /api/products
// @access  Public
router.get('/', async (req, res) => {
  try {
    const products = await Product.find()
      .populate('farmer', 'name location')
      .sort('-createdAt');
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// @desc    Get farmer's products
// @route   GET /api/products/farmer
// @access  Private/Farmer
router.get('/farmer', auth, farmerAuth, async (req, res) => {
  try {
    const products = await Product.find({ farmer: req.user._id })
      .sort('-createdAt');
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// @desc    Create a product
// @route   POST /api/products
// @access  Private/Farmer
router.post('/', auth, farmerAuth, upload.single('image'), async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      quantity,
      unit,
      category,
      location,
      harvestDate,
      expiryDate,
    } = req.body;

    let imageUrl = 'https://via.placeholder.com/300';
    if (req.file) {
      imageUrl = `http://localhost:5001/uploads/products/${req.file.filename}`;
    }

    const product = await Product.create({
      name,
      description,
      price,
      quantity,
      unit,
      category,
      imageUrl,
      location,
      harvestDate,
      expiryDate,
      farmer: req.user._id,
    });

    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private/Farmer
router.put('/:id', auth, farmerAuth, upload.single('image'), async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if the product belongs to the farmer
    if (product.farmer.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this product' });
    }

    const {
      name,
      description,
      price,
      quantity,
      unit,
      category,
      location,
      harvestDate,
      expiryDate,
    } = req.body;

    let imageUrl = product.imageUrl;
    if (req.file) {
      imageUrl = `http://localhost:5001/uploads/products/${req.file.filename}`;
    }

    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      {
        name,
        description,
        price,
        quantity,
        unit,
        category,
        imageUrl,
        location,
        harvestDate,
        expiryDate,
      },
      { new: true }
    );

    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private/Farmer
router.delete('/:id', auth, farmerAuth, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if the product belongs to the farmer
    if (product.farmer.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this product' });
    }

    // Delete the image file if it exists
    if (product.imageUrl && product.imageUrl.startsWith('/uploads/')) {
      const imagePath = path.join(__dirname, '..', product.imageUrl);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }

    await product.remove();
    res.json({ message: 'Product removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Serve static files
router.use('/uploads/products', express.static('uploads/products'));

module.exports = router;
