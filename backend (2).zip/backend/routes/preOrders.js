const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const PreOrder = require('../models/PreOrder');
const User = require('../models/User');
const Razorpay = require('razorpay');
const crypto = require('crypto');

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Create new pre-order
router.post('/', auth, async (req, res) => {
  try {
    const {
      crop,
      variety,
      quantity,
      unit,
      expectedHarvestDate,
      pricePerUnit
    } = req.body;

    // Validate user roles
    if (req.user.role !== 'buyer') {
      return res.status(403).json({ message: 'Only buyers can create pre-orders' });
    }

    // Create pre-order
    const preOrder = new PreOrder({
      buyer: req.user._id,
      farmer: req.body.farmer, // Farmer ID from request
      crop,
      variety,
      quantity,
      unit,
      expectedHarvestDate,
      pricePerUnit,
      totalPrice: quantity * pricePerUnit
    });

    // Calculate deposit amount (20% of total price)
    preOrder.depositAmount = preOrder.totalPrice * 0.2;

    await preOrder.save();

    // Create Razorpay order for deposit payment
    const options = {
      amount: preOrder.depositAmount * 100, // Convert to paise
      currency: 'INR',
      receipt: 'preorder_' + preOrder._id,
      payment_capture: 1
    };

    const razorpayOrder = await razorpay.orders.create(options);

    res.json({
      preOrder,
      payment: {
        id: razorpayOrder.id,
        amount: razorpayOrder.amount,
        currency: razorpayOrder.currency,
        key: process.env.RAZORPAY_KEY_ID
      }
    });
  } catch (error) {
    console.error('Error creating pre-order:', error);
    res.status(500).json({ message: 'Failed to create pre-order' });
  }
});

// Verify deposit payment
router.post('/payment/verify', auth, async (req, res) => {
  try {
    const {
      razorpayPaymentId,
      razorpayOrderId,
      razorpaySignature,
      preOrderId
    } = req.body;

    // Verify signature
    const sign = razorpayOrderId + '|' + razorpayPaymentId;
    const expectedSign = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(sign)
      .digest('hex');

    if (razorpaySignature !== expectedSign) {
      return res.status(400).json({ message: 'Invalid payment signature' });
    }

    const preOrder = await PreOrder.findById(preOrderId);
    if (!preOrder) {
      return res.status(404).json({ message: 'Pre-order not found' });
    }

    // Update payment details
    preOrder.paymentDetails = {
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature
    };
    preOrder.depositPaid = true;
    preOrder.paymentStatus = 'partial';
    await preOrder.save();

    res.json({
      message: 'Deposit payment verified successfully',
      preOrder
    });
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ message: 'Payment verification failed' });
  }
});

// Get buyer's pre-orders
router.get('/buyer', auth, async (req, res) => {
  try {
    if (req.user.role !== 'buyer') {
      return res.status(403).json({ message: 'Only buyers can view their pre-orders' });
    }

    const preOrders = await PreOrder.find({ buyer: req.user._id })
      .populate('farmer', 'name email phone')
      .sort({ createdAt: -1 });

    res.json(preOrders);
  } catch (error) {
    console.error('Error fetching buyer pre-orders:', error);
    res.status(500).json({ message: 'Failed to fetch pre-orders' });
  }
});

// Get farmer's pre-orders
router.get('/farmer', auth, async (req, res) => {
  try {
    if (req.user.role !== 'farmer') {
      return res.status(403).json({ message: 'Only farmers can view their pre-orders' });
    }

    const preOrders = await PreOrder.find({ farmer: req.user._id })
      .populate('buyer', 'name email phone')
      .sort({ expectedHarvestDate: 1 });

    res.json(preOrders);
  } catch (error) {
    console.error('Error fetching farmer pre-orders:', error);
    res.status(500).json({ message: 'Failed to fetch pre-orders' });
  }
});

// Update pre-order status (farmer only)
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const preOrder = await PreOrder.findById(req.params.id);

    if (!preOrder) {
      return res.status(404).json({ message: 'Pre-order not found' });
    }

    // Check if user is the farmer
    if (preOrder.farmer.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Only farmer can update pre-order status' });
    }

    // Validate status transition
    const validTransitions = {
      pending: ['confirmed', 'rejected'],
      confirmed: ['completed', 'cancelled'],
      rejected: [],
      completed: [],
      cancelled: []
    };

    if (!validTransitions[preOrder.status].includes(status)) {
      return res.status(400).json({
        message: 'Invalid status transition',
        allowedStatuses: validTransitions[preOrder.status]
      });
    }

    preOrder.status = status;
    await preOrder.save();

    res.json(preOrder);
  } catch (error) {
    console.error('Error updating pre-order status:', error);
    res.status(500).json({ message: 'Failed to update pre-order status' });
  }
});

// Get pre-order by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const preOrder = await PreOrder.findById(req.params.id)
      .populate('buyer', 'name email phone')
      .populate('farmer', 'name email phone');

    if (!preOrder) {
      return res.status(404).json({ message: 'Pre-order not found' });
    }

    // Check if user is authorized
    if (preOrder.buyer.toString() !== req.user.id && 
        preOrder.farmer.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to view this pre-order' });
    }

    res.json(preOrder);
  } catch (error) {
    console.error('Error fetching pre-order:', error);
    res.status(500).json({ message: 'Failed to fetch pre-order' });
  }
});

module.exports = router;
