const express = require('express');
const router = express.Router();
const {
  getProducts,
  getFarmerProducts,
  createProduct,
  updateProduct,
  deleteProduct,
} = require('../controllers/productController');
const { protect, isFarmer } = require('../middleware/authMiddleware');

router.get('/', getProducts);
router.get('/farmer', protect, isFarmer, getFarmerProducts);
router.post('/', protect, isFarmer, createProduct);
router.put('/:id', protect, isFarmer, updateProduct);
router.delete('/:id', protect, isFarmer, deleteProduct);

module.exports = router;
