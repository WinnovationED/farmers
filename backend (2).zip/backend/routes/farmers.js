const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const multer = require('multer');
const path = require('path');

// Configure multer for image upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Not an image! Please upload an image.'), false);
    }
  }
});

// GET /api/farmers/profile - Get farmer profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.role !== 'farmer') {
      return res.status(403).json({ message: 'Access denied. Not a farmer.' });
    }

    res.json(user);
  } catch (error) {
    console.error('Error fetching farmer profile:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT /api/farmers/profile - Update farmer profile
router.put('/profile', auth, async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      location,
      farmName,
      farmSize,
      cropTypes
    } = req.body;

    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.role !== 'farmer') {
      return res.status(403).json({ message: 'Access denied. Not a farmer.' });
    }

    // Update fields
    if (name) user.name = name;
    if (email) user.email = email;
    if (phone) user.phone = phone;
    if (location) user.location = location;
    if (farmName) user.farmName = farmName;
    if (farmSize) user.farmSize = farmSize;
    if (cropTypes) user.cropTypes = cropTypes;

    await user.save();
    res.json(user);
  } catch (error) {
    console.error('Error updating farmer profile:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/farmers/profile/image - Upload profile image
router.post('/profile/image', auth, upload.single('image'), async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.role !== 'farmer') {
      return res.status(403).json({ message: 'Access denied. Not a farmer.' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Please upload an image' });
    }

    const imageUrl = `/uploads/${req.file.filename}`;
    user.image = imageUrl;
    await user.save();

    res.json({ imageUrl });
  } catch (error) {
    console.error('Error uploading profile image:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
