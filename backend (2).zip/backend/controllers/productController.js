const asyncHandler = require('express-async-handler');
const Product = require('../models/productModel');

// @desc    Get all products
// @route   GET /api/products
// @access  Public
const getProducts = asyncHandler(async (req, res) => {
  const { category, location, search } = req.query;
  let query = { available: true };

  if (category) {
    query.category = category;
  }

  if (location) {
    query.location = { $regex: location, $options: 'i' };
  }

  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
    ];
  }

  const products = await Product.find(query)
    .populate('farmer', 'name location')
    .sort('-createdAt');

  res.json(products);
});

// @desc    Get farmer's products
// @route   GET /api/products/farmer
// @access  Private/Farmer
const getFarmerProducts = asyncHandler(async (req, res) => {
  const products = await Product.find({ farmer: req.user._id })
    .sort('-createdAt');
  res.json(products);
});

// @desc    Create a product
// @route   POST /api/products
// @access  Private/Farmer
const createProduct = asyncHandler(async (req, res) => {
  const {
    name,
    description,
    price,
    quantity,
    unit,
    category,
    imageUrl,
    location,
    harvestDate,
    expiryDate,
  } = req.body;

  const product = await Product.create({
    name,
    description,
    price,
    quantity,
    unit,
    category,
    imageUrl,
    location,
    harvestDate,
    expiryDate,
    farmer: req.user._id,
  });

  res.status(201).json(product);
});

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private/Farmer
const updateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);

  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  // Check if the product belongs to the farmer
  if (product.farmer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this product');
  }

  const updatedProduct = await Product.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );

  res.json(updatedProduct);
});

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private/Farmer
const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);

  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  // Check if the product belongs to the farmer
  if (product.farmer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this product');
  }

  await product.remove();
  res.json({ message: 'Product removed' });
});

module.exports = {
  getProducts,
  getFarmerProducts,
  createProduct,
  updateProduct,
  deleteProduct,
};
