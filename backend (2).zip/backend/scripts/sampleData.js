const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/userModel');
const Product = require('../models/productModel');
const bcrypt = require('bcryptjs');

dotenv.config({ path: '../.env' });

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB Connected');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    process.exit(1);
  }
};

const createSampleData = async () => {
  try {
    // Create a sample farmer
    const hashedPassword = await bcrypt.hash('password123', 12);
    const farmer = await User.create({
      name: 'John Farmer',
      email: 'john@farmer.com',
      password: hashedPassword,
      phone: '1234567890',
      location: 'Delhi',
      userType: 'farmer',
      cropTypes: ['Vegetables', 'Fruits']
    });

    // Create sample products
    const products = [
      {
        name: 'Fresh Tomatoes',
        description: 'Organic, locally grown tomatoes',
        price: 40,
        quantity: 100,
        unit: 'kg',
        category: 'Vegetables',
        location: 'Delhi',
        farmer: farmer._id,
        imageUrl: 'https://images.unsplash.com/photo-1546470427-1ec6068c9b10?ixlib=rb-4.0.3',
        harvestDate: new Date(),
        expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      },
      {
        name: 'Organic Apples',
        description: 'Sweet and juicy apples from our orchard',
        price: 120,
        quantity: 50,
        unit: 'kg',
        category: 'Fruits',
        location: 'Delhi',
        farmer: farmer._id,
        imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?ixlib=rb-4.0.3',
        harvestDate: new Date(),
        expiryDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
      },
      {
        name: 'Fresh Carrots',
        description: 'Crunchy and nutritious carrots',
        price: 60,
        quantity: 75,
        unit: 'kg',
        category: 'Vegetables',
        location: 'Delhi',
        farmer: farmer._id,
        imageUrl: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3',
        harvestDate: new Date(),
        expiryDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
      }
    ];

    await Product.insertMany(products);
    console.log('Sample data created successfully');
  } catch (error) {
    console.error('Error creating sample data:', error);
  } finally {
    mongoose.disconnect();
  }
};

connectDB().then(() => {
  createSampleData();
});
