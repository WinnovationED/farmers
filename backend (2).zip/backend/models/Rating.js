const mongoose = require('mongoose');

const ratingSchema = new mongoose.Schema({
  order: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order',
    required: true
  },
  rater: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  recipient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  review: {
    type: String,
    required: true,
    trim: true,
    minlength: 10,
    maxlength: 500
  },
  deliveryPhotos: [{
    type: String, // URLs to photos
    validate: {
      validator: function(v) {
        return v.startsWith('http://') || v.startsWith('https://');
      },
      message: 'Invalid photo URL'
    }
  }],
  type: {
    type: String,
    required: true,
    enum: ['farmer-to-buyer', 'buyer-to-farmer']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Ensure one rating per order per type
ratingSchema.index({ order: 1, type: 1 }, { unique: true });

// Calculate average rating for a user
ratingSchema.statics.calculateAverageRating = async function(userId) {
  const result = await this.aggregate([
    { $match: { recipient: mongoose.Types.ObjectId(userId) } },
    { $group: {
      _id: null,
      averageRating: { $avg: '$rating' },
      totalRatings: { $sum: 1 }
    }}
  ]);
  return result[0] || { averageRating: 0, totalRatings: 0 };
};

const Rating = mongoose.model('Rating', ratingSchema);

module.exports = Rating;
