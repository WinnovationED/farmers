const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const cartItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  }
});

const farmerProfileSchema = new mongoose.Schema({
  farmName: {
    type: String,
    required: [true, 'Farm name is required for farmers']
  },
  farmSize: {
    type: Number,
    required: [true, 'Farm size is required for farmers']
  },
  farmLocation: {
    type: String,
    required: [true, 'Farm location is required for farmers']
  },
  cropTypes: [{
    type: String,
    enum: ['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Poultry', 'Meat', 'Organic', 'Others']
  }],
  experienceYears: {
    type: Number,
    min: 0
  },
  certification: {
    type: String,
    enum: ['Organic', 'Conventional', 'None']
  },
  bio: {
    type: String,
    maxlength: 500
  },
  profileImage: {
    type: String,
    default: 'https://via.placeholder.com/150'
  }
});

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  password: {
    type: String,
    required: true,
    minlength: [6, 'Password must be at least 6 characters long']
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true
  },
  role: {
    type: String,
    enum: {
      values: ['farmer', 'buyer'],
      message: '{VALUE} is not a valid role'
    },
    required: true
  },
  location: {
    type: String,
    required: [true, 'Location is required'],
    trim: true
  },
  farmerProfile: {
    type: farmerProfileSchema,
    default: null
  },
  shippingAddresses: [{
    street: String,
    city: String,
    state: String,
    zipCode: String,
    isDefault: Boolean
  }],
  cart: [cartItemSchema],
  favorites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Add validation for farmer profile if role is farmer
userSchema.pre('save', function(next) {
  if (this.role === 'farmer' && (!this.farmerProfile || !this.farmerProfile.farmName || !this.farmerProfile.farmSize || !this.farmerProfile.farmLocation)) {
    next(new Error('Farmer profile is required for farmers'));
  }
  next();
});

module.exports = mongoose.model('User', userSchema);
