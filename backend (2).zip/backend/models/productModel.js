const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide product name'],
  },
  description: {
    type: String,
    required: [true, 'Please provide product description'],
  },
  price: {
    type: Number,
    required: [true, 'Please provide product price'],
  },
  quantity: {
    type: Number,
    required: [true, 'Please provide product quantity'],
  },
  unit: {
    type: String,
    required: [true, 'Please provide unit (e.g., kg, pieces)'],
  },
  category: {
    type: String,
    required: [true, 'Please provide product category'],
    enum: ['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Poultry', 'Meat', 'Organic', 'Others'],
  },
  imageUrl: {
    type: String,
    default: 'https://via.placeholder.com/300',
  },
  farmer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  location: {
    type: String,
    required: [true, 'Please provide product location'],
  },
  available: {
    type: Boolean,
    default: true,
  },
  harvestDate: {
    type: Date,
  },
  expiryDate: {
    type: Date,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Product', productSchema);
