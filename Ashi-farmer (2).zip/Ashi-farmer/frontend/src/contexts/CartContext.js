import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();

  // Fetch cart items from backend
  const fetchCartItems = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token || !user) {
        setCartItems([]);
        return;
      }

      const response = await fetch('http://localhost:5001/api/cart', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch cart items');
      }

      const data = await response.json();
      setCartItems(data.items || []);
    } catch (error) {
      console.error('Error fetching cart:', error);
      setCartItems([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch cart items when user changes
  useEffect(() => {
    fetchCartItems();
  }, [user]);

  const addToCart = async (product, quantity = 1) => {
    try {
      const token = localStorage.getItem('token');
      if (!token || !user) {
        throw new Error('Please login to add items to cart');
      }

      const response = await fetch('http://localhost:5001/api/cart/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          productId: product._id,
          quantity
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.message?.includes('Insufficient stock')) {
          throw {
            message: 'Insufficient stock',
            availableQuantity: errorData.availableQuantity
          };
        }
        throw new Error(errorData.message || 'Failed to add item to cart');
      }

      // Refresh cart items
      await fetchCartItems();
      return true;
    } catch (error) {
      console.error('Error adding to cart:', error);
      setError(error);
      throw error;
    }
  };

  const removeFromCart = async (productId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token || !user) {
        throw new Error('Please login to remove items from cart');
      }

      const response = await fetch(`http://localhost:5001/api/cart/remove/${productId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to remove item from cart');
      }

      // Refresh cart items
      await fetchCartItems();
      return true;
    } catch (error) {
      console.error('Error removing from cart:', error);
      setError(error);
      throw error;
    }
  };

  const updateQuantity = async (productId, newQuantity) => {
    try {
      const token = localStorage.getItem('token');
      if (!token || !user) {
        throw new Error('Please login to update cart');
      }

      const response = await fetch('http://localhost:5001/api/cart/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          productId,
          quantity: newQuantity
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.message?.includes('Insufficient stock')) {
          throw {
            message: 'Insufficient stock',
            availableQuantity: errorData.availableQuantity
          };
        }
        throw new Error(errorData.message || 'Failed to update cart quantity');
      }

      // Refresh cart items
      await fetchCartItems();
      return true;
    } catch (error) {
      console.error('Error updating cart quantity:', error);
      setError(error);
      throw error;
    }
  };

  const clearCart = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token || !user) {
        throw new Error('Please login to clear cart');
      }

      const response = await fetch('http://localhost:5001/api/cart/clear', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to clear cart');
      }

      // Refresh cart items
      await fetchCartItems();
      return true;
    } catch (error) {
      console.error('Error clearing cart:', error);
      setError(error);
      throw error;
    }
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);
  };

  const getCartItemCount = () => {
    return cartItems.reduce((count, item) => {
      return count + item.quantity;
    }, 0);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        loading,
        error,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getCartTotal,
        getCartItemCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
