import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline, Container } from '@mui/material';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProductsPage from './pages/ProductsPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import PreBookingPage from './pages/PreBookingPage';
import FarmerDashboardPage from './pages/FarmerDashboardPage';
import AddProductPage from './pages/AddProductPage';
import RatingPage from './pages/RatingPage';
import CartPage from './pages/CartPage';
import FavoritesPage from './pages/FavoritesPage';
import BuyerProfile from './components/BuyerProfile';
import FarmerProfile from './components/FarmerProfile';
import Dashboard from './components/Dashboard';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import OrderPage from './pages/OrderPage';
import OrderConfirmationPage from './pages/OrderConfirmationPage';
import CheckoutForm from './components/CheckoutForm';
import OrderConfirmation from './components/OrderConfirmation';
import { theme } from './styles/theme';
import './styles/GlobalStyles.css';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import PreOrders from './pages/PreOrders'; // Import PreOrders component

// Protected Route Component
const ProtectedRoute = ({ children, farmerOnly, buyerOnly }) => {
  const { user } = useAuth();

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (farmerOnly && user.role !== 'farmer') {
    return <Navigate to="/" />;
  }

  if (buyerOnly && user.role !== 'buyer') {
    return <Navigate to="/" />;
  }

  return typeof children === 'function' ? children({ user }) : children;
};

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <CartProvider>
          <Router>
            <Navbar />
            <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
              <Routes>
                <Route path="/" element={<ProductsPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route
                  path="/dashboard/*"
                  element={
                    <ProtectedRoute farmerOnly>
                      <Dashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/add-product"
                  element={
                    <ProtectedRoute farmerOnly>
                      <AddProductPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/products/add"
                  element={
                    <ProtectedRoute farmerOnly>
                      <AddProductPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/add-product"
                  element={
                    <ProtectedRoute farmerOnly>
                      <AddProductPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/pre-booking"
                  element={
                    <ProtectedRoute>
                      <PreBookingPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/rating"
                  element={
                    <ProtectedRoute>
                      <RatingPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/cart"
                  element={
                    <ProtectedRoute buyerOnly>
                      <CartPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/favorites"
                  element={
                    <ProtectedRoute buyerOnly>
                      <FavoritesPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/profile"
                  element={
                    <ProtectedRoute>
                      {({ user }) => user.role === 'farmer' ? <FarmerProfile /> : <BuyerProfile />}
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/order"
                  element={
                    <ProtectedRoute buyerOnly>
                      <OrderPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/checkout"
                  element={
                    <ProtectedRoute buyerOnly>
                      <CheckoutForm />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/order-confirmation"
                  element={
                    <ProtectedRoute buyerOnly>
                      <OrderConfirmation />
                    </ProtectedRoute>
                  }
                />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route
                  path="/pre-orders"
                  element={
                    <ProtectedRoute>
                      <PreOrders />
                    </ProtectedRoute>
                  }
                />
              </Routes>
            </Container>
            <Footer />
          </Router>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
