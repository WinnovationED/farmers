import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  Divider,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Badge,
  Avatar,
  Chip
} from '@mui/material';
import {
  Delete as DeleteIcon,
  ShoppingCart as CartIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  Person as PersonIcon
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

const BuyerProfile = () => {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState([]);
  const [orderHistory, setOrderHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCartItems();
    fetchOrderHistory();
  }, []);

  const fetchCartItems = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5001/api/cart', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setCartItems(data.items || []);
      }
    } catch (error) {
      console.error('Error fetching cart:', error);
    }
  };

  const fetchOrderHistory = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5001/api/orders/history', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setOrderHistory(data || []);
      }
    } catch (error) {
      console.error('Error fetching order history:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId, change) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5001/api/cart/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          productId,
          quantity: change
        })
      });
      
      if (response.ok) {
        fetchCartItems(); // Refresh cart after update
      }
    } catch (error) {
      console.error('Error updating cart:', error);
    }
  };

  const removeFromCart = async (productId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:5001/api/cart/remove/${productId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        fetchCartItems(); // Refresh cart after removal
      }
    } catch (error) {
      console.error('Error removing item from cart:', error);
    }
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Grid container spacing={3}>
        {/* Profile Information */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Avatar
                src={user?.profileImage}
                sx={{ width: 80, height: 80, mr: 2 }}
              >
                <PersonIcon />
              </Avatar>
              <Box>
                <Typography variant="h6">{user?.name}</Typography>
                <Typography color="textSecondary">{user?.email}</Typography>
              </Box>
            </Box>
            <Divider sx={{ my: 2 }} />
            <List>
              <ListItem>
                <ListItemText 
                  primary="Phone"
                  secondary={user?.phone || 'Not provided'}
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Location"
                  secondary={user?.location || 'Not provided'}
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Member Since"
                  secondary={new Date(user?.createdAt).toLocaleDateString()}
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>

        {/* Shopping Cart */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Badge badgeContent={cartItems.length} color="primary">
                <CartIcon />
              </Badge>
              <Typography variant="h6" sx={{ ml: 2 }}>Shopping Cart</Typography>
            </Box>
            
            {cartItems.length === 0 ? (
              <Typography color="textSecondary" sx={{ py: 3, textAlign: 'center' }}>
                Your cart is empty
              </Typography>
            ) : (
              <>
                <List>
                  {cartItems.map((item) => (
                    <Card key={item._id} sx={{ mb: 2 }}>
                      <Box sx={{ display: 'flex' }}>
                        <CardMedia
                          component="img"
                          sx={{ width: 100, height: 100, objectFit: 'cover' }}
                          image={item.image || 'https://via.placeholder.com/100'}
                          alt={item.name}
                        />
                        <CardContent sx={{ flex: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Box>
                            <Typography variant="h6">{item.name}</Typography>
                            <Typography variant="body2" color="textSecondary">
                              Price: ₹{item.price}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <IconButton onClick={() => updateQuantity(item._id, -1)} disabled={item.quantity <= 1}>
                              <RemoveIcon />
                            </IconButton>
                            <Typography sx={{ mx: 2 }}>{item.quantity}</Typography>
                            <IconButton onClick={() => updateQuantity(item._id, 1)}>
                              <AddIcon />
                            </IconButton>
                            <IconButton onClick={() => removeFromCart(item._id)} color="error">
                              <DeleteIcon />
                            </IconButton>
                          </Box>
                        </CardContent>
                      </Box>
                    </Card>
                  ))}
                </List>
                <Divider sx={{ my: 2 }} />
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="h6">
                    Total: ₹{calculateTotal()}
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<CartIcon />}
                    href="/checkout"
                  >
                    Proceed to Checkout
                  </Button>
                </Box>
              </>
            )}
          </Paper>

          {/* Recent Orders */}
          <Paper sx={{ p: 3, mt: 3 }}>
            <Typography variant="h6" gutterBottom>Recent Orders</Typography>
            {orderHistory.length === 0 ? (
              <Typography color="textSecondary" sx={{ py: 2, textAlign: 'center' }}>
                No orders yet
              </Typography>
            ) : (
              <List>
                {orderHistory.slice(0, 5).map((order) => (
                  <ListItem key={order._id} divider>
                    <ListItemText
                      primary={`Order #${order._id.slice(-6)}`}
                      secondary={`Placed on ${new Date(order.createdAt).toLocaleDateString()}`}
                    />
                    <Box>
                      <Chip
                        label={order.status}
                        color={
                          order.status === 'delivered' ? 'success' :
                          order.status === 'processing' ? 'warning' : 'default'
                        }
                        size="small"
                      />
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        ₹{order.total}
                      </Typography>
                    </Box>
                  </ListItem>
                ))}
              </List>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default BuyerProfile;
