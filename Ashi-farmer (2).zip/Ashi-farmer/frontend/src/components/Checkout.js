import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  TextField,
  Typography,
  Alert,
  CircularProgress,
  Grid,
  Divider
} from '@mui/material';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import axios from 'axios';

// Initialize Stripe (replace with your publishable key)
const stripePromise = loadStripe('your_publishable_key');

const CheckoutForm = ({ product, quantity, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [clientSecret, setClientSecret] = useState('');
  const [transactionId, setTransactionId] = useState(null);

  useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        const response = await axios.post('http://localhost:5000/api/payments/create-payment-intent', {
          productId: product._id,
          quantity,
          buyerId: '12345' // Replace with actual buyer ID from auth
        });
        setClientSecret(response.data.clientSecret);
        setTransactionId(response.data.transactionId);
      } catch (err) {
        setError('Error initializing payment. Please try again.');
      }
    };

    if (product && quantity) {
      createPaymentIntent();
    }
  }, [product, quantity]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);

    if (!stripe || !elements) {
      return;
    }

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: elements.getElement(CardElement),
        billing_details: {
          name: 'Test User', // Replace with actual user name
        },
      },
    });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
    } else if (paymentIntent.status === 'succeeded') {
      try {
        await axios.post('http://localhost:5000/api/payments/confirm-payment', {
          transactionId
        });
        onSuccess();
      } catch (err) {
        setError('Payment confirmed but error updating order. Please contact support.');
      }
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Order Summary
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={8}>
            <Typography>{product.name}</Typography>
          </Grid>
          <Grid item xs={4}>
            <Typography align="right">₹{product.price * quantity}</Typography>
          </Grid>
          <Grid item xs={8}>
            <Typography color="text.secondary">Quantity</Typography>
          </Grid>
          <Grid item xs={4}>
            <Typography align="right">{quantity}</Typography>
          </Grid>
        </Grid>
        <Divider sx={{ my: 2 }} />
        <Grid container>
          <Grid item xs={8}>
            <Typography variant="h6">Total</Typography>
          </Grid>
          <Grid item xs={4}>
            <Typography variant="h6" align="right">₹{product.price * quantity}</Typography>
          </Grid>
        </Grid>
      </Box>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Card Details
        </Typography>
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#424770',
                '::placeholder': {
                  color: '#aab7c4',
                },
              },
              invalid: {
                color: '#9e2146',
              },
            },
          }}
        />
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Button
        type="submit"
        variant="contained"
        color="primary"
        fullWidth
        disabled={!stripe || loading}
        sx={{ mt: 2 }}
      >
        {loading ? <CircularProgress size={24} /> : `Pay ₹${product.price * quantity}`}
      </Button>
    </form>
  );
};

const Checkout = ({ product, quantity, onSuccess, onCancel }) => {
  return (
    <Container maxWidth="sm" sx={{ py: 4 }}>
      <Card>
        <CardContent>
          <Typography variant="h5" gutterBottom>
            Secure Checkout
          </Typography>
          <Elements stripe={stripePromise}>
            <CheckoutForm 
              product={product}
              quantity={quantity}
              onSuccess={onSuccess}
            />
          </Elements>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Checkout;
