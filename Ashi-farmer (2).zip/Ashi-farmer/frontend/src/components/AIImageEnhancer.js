import React, { useState } from 'react';
import {
  Box,
  IconButton,
  Tooltip,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Fade,
  Zoom,
} from '@mui/material';
import {
  CameraAlt,
  AutoFixHigh,
  ZoomIn,
  RestartAlt,
} from '@mui/icons-material';

const AIImageEnhancer = ({ imageUrl, onEnhancedImage }) => {
  const [loading, setLoading] = useState(false);
  const [enhancedImage, setEnhancedImage] = useState(null);
  const [showOriginal, setShowOriginal] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [error, setError] = useState(null);

  const handleEnhanceImage = async () => {
    try {
      setLoading(true);
      setError(null);

      // Call AI image enhancement API (replace with your actual API endpoint)
      const response = await fetch('http://localhost:5001/api/enhance-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ imageUrl }),
      });

      if (!response.ok) {
        throw new Error('Failed to enhance image');
      }

      const data = await response.json();
      setEnhancedImage(data.enhancedUrl);
      onEnhancedImage(data.enhancedUrl);
    } catch (err) {
      console.error('Error enhancing image:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleToggleOriginal = () => {
    setShowOriginal(!showOriginal);
  };

  const handleResetImage = () => {
    setEnhancedImage(null);
    onEnhancedImage(imageUrl);
  };

  return (
    <>
      <Box sx={{ position: 'relative' }}>
        <Box
          component="img"
          src={enhancedImage || imageUrl}
          alt="Product"
          sx={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            borderRadius: 2,
            transition: 'transform 0.3s ease-in-out',
            '&:hover': {
              transform: 'scale(1.05)',
            },
          }}
        />
        
        <Box
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            display: 'flex',
            gap: 1,
            opacity: 0.8,
            transition: 'opacity 0.3s ease',
            '&:hover': {
              opacity: 1,
            },
          }}
        >
          <Tooltip title="Enhance with AI" arrow>
            <IconButton
              onClick={handleEnhanceImage}
              disabled={loading}
              sx={{
                bgcolor: 'background.paper',
                '&:hover': {
                  bgcolor: 'background.paper',
                  transform: 'scale(1.1)',
                },
              }}
            >
              {loading ? (
                <CircularProgress size={24} />
              ) : (
                <AutoFixHigh color="primary" />
              )}
            </IconButton>
          </Tooltip>

          {enhancedImage && (
            <>
              <Tooltip title="Compare with original" arrow>
                <IconButton
                  onMouseEnter={handleToggleOriginal}
                  onMouseLeave={handleToggleOriginal}
                  sx={{
                    bgcolor: 'background.paper',
                    '&:hover': {
                      bgcolor: 'background.paper',
                      transform: 'scale(1.1)',
                    },
                  }}
                >
                  <CameraAlt color="primary" />
                </IconButton>
              </Tooltip>

              <Tooltip title="Reset image" arrow>
                <IconButton
                  onClick={handleResetImage}
                  sx={{
                    bgcolor: 'background.paper',
                    '&:hover': {
                      bgcolor: 'background.paper',
                      transform: 'scale(1.1)',
                    },
                  }}
                >
                  <RestartAlt color="primary" />
                </IconButton>
              </Tooltip>
            </>
          )}

          <Tooltip title="View full size" arrow>
            <IconButton
              onClick={handleOpenDialog}
              sx={{
                bgcolor: 'background.paper',
                '&:hover': {
                  bgcolor: 'background.paper',
                  transform: 'scale(1.1)',
                },
              }}
            >
              <ZoomIn color="primary" />
            </IconButton>
          </Tooltip>
        </Box>

        <Fade in={showOriginal}>
          <Box
            component="img"
            src={imageUrl}
            alt="Original"
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              borderRadius: 2,
            }}
          />
        </Fade>

        {error && (
          <Zoom in>
            <Box
              sx={{
                position: 'absolute',
                bottom: 8,
                left: 8,
                right: 8,
                bgcolor: 'error.main',
                color: 'error.contrastText',
                p: 1,
                borderRadius: 1,
                textAlign: 'center',
              }}
            >
              <Typography variant="caption">{error}</Typography>
            </Box>
          </Zoom>
        )}
      </Box>

      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          Product Image
          {enhancedImage && (
            <Typography variant="caption" sx={{ ml: 1, color: 'success.main' }}>
              (AI Enhanced)
            </Typography>
          )}
        </DialogTitle>
        <DialogContent>
          <Box
            component="img"
            src={enhancedImage || imageUrl}
            alt="Product full size"
            sx={{
              width: '100%',
              height: 'auto',
              objectFit: 'contain',
              borderRadius: 2,
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Close</Button>
          {enhancedImage && (
            <Button
              color="primary"
              onClick={() => window.open(enhancedImage, '_blank')}
            >
              Download Enhanced Image
            </Button>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default AIImageEnhancer;
