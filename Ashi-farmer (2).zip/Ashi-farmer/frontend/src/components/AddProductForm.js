import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Typography,
  Paper,
  InputAdornment,
  FormHelperText,
  Snackbar,
  Alert,
  CircularProgress
} from '@mui/material';
import { Add, CloudUpload, AutoFixHigh } from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const AddProductForm = ({ onProductAdded }) => {
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    quantity: '',
    unit: '',
    location: user?.location || '',
    image: null,
    imagePreview: null
  });

  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!token) {
      setNotification({
        open: true,
        message: 'Please login to add products',
        severity: 'error'
      });
      navigate('/login');
    } else if (!user || user.role !== 'farmer') {
      setNotification({
        open: true,
        message: 'Only farmers can add products',
        severity: 'error'
      });
      navigate('/');
    }
  }, [user, token, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setNotification({
          open: true,
          message: 'Image size should be less than 5MB',
          severity: 'error'
        });
        return;
      }

      if (!['image/jpeg', 'image/jpg', 'image/png'].includes(file.type)) {
        setNotification({
          open: true,
          message: 'Only JPEG, JPG and PNG files are allowed',
          severity: 'error'
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          image: file,
          imagePreview: reader.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const generateAIImage = async () => {
    if (!token) {
      setNotification({
        open: true,
        message: 'Please login to generate AI images',
        severity: 'error'
      });
      navigate('/login');
      return;
    }

    try {
      setIsGeneratingImage(true);
      
      const prompt = `High quality product photo of ${formData.name}, ${formData.category}, on white background, professional lighting, 4k`;
      
      const response = await fetch('http://localhost:5001/api/images/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ prompt })
      });

      if (!response.ok) {
        const error = await response.json();
        if (response.status === 401) {
          navigate('/login');
        }
        throw new Error(error.message || 'Failed to generate image');
      }

      const data = await response.json();
      
      // Convert URL to File object
      const imageResponse = await fetch(data.imageUrl);
      const blob = await imageResponse.blob();
      const file = new File([blob], 'ai-generated.png', { type: 'image/png' });

      setFormData(prev => ({
        ...prev,
        image: file,
        imagePreview: data.imageUrl
      }));

      setNotification({
        open: true,
        message: 'AI image generated successfully!',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error generating AI image:', error);
      setNotification({
        open: true,
        message: error.message || 'Failed to generate AI image',
        severity: 'error'
      });
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setNotification({
        open: true,
        message: 'Please login to add products',
        severity: 'error'
      });
      navigate('/login');
      return;
    }

    if (!user || user.role !== 'farmer') {
      setNotification({
        open: true,
        message: 'Only farmers can add products',
        severity: 'error'
      });
      navigate('/');
      return;
    }

    setLoading(true);
    
    try {
      // Validate required fields
      const requiredFields = ['name', 'description', 'price', 'category', 'quantity', 'unit', 'location'];
      for (const field of requiredFields) {
        if (!formData[field]) {
          throw new Error(`Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}`);
        }
      }

      // Validate numeric fields
      if (isNaN(parseFloat(formData.price)) || parseFloat(formData.price) <= 0) {
        throw new Error('Please enter a valid price');
      }
      if (isNaN(parseFloat(formData.quantity)) || parseFloat(formData.quantity) <= 0) {
        throw new Error('Please enter a valid quantity');
      }

      const formDataToSend = new FormData();
      Object.keys(formData).forEach(key => {
        if (key !== 'imagePreview') {
          if (key === 'image' && formData[key]) {
            formDataToSend.append(key, formData[key]);
          } else if (key !== 'image') {
            formDataToSend.append(key, formData[key]);
          }
        }
      });

      // Add farmer ID from user object
      if (!user._id) {
        throw new Error('User ID not found. Please try logging in again.');
      }
      formDataToSend.append('farmer', user._id);

      console.log('Submitting product with data:', {
        name: formDataToSend.get('name'),
        description: formDataToSend.get('description'),
        price: formDataToSend.get('price'),
        category: formDataToSend.get('category'),
        quantity: formDataToSend.get('quantity'),
        unit: formDataToSend.get('unit'),
        location: formDataToSend.get('location'),
        farmer: formDataToSend.get('farmer'),
        hasImage: formDataToSend.has('image')
      });

      const response = await fetch('http://localhost:5001/api/products', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formDataToSend
      });
      
      if (!response.ok) {
        const data = await response.json();
        if (response.status === 401) {
          navigate('/login');
        }
        throw new Error(data.message || 'Failed to add product');
      }

      const data = await response.json();

      setNotification({
        open: true,
        message: 'Product added successfully!',
        severity: 'success'
      });

      // Reset form
      setFormData({
        name: '',
        description: '',
        price: '',
        category: '',
        quantity: '',
        unit: '',
        location: user?.location || '',
        image: null,
        imagePreview: null
      });

      // Notify parent component
      if (onProductAdded) {
        onProductAdded(data);
      }
    } catch (error) {
      console.error('Error adding product:', error);
      setNotification({
        open: true,
        message: error.message || 'Failed to add product. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user || !token) {
    return (
      <Paper elevation={3} sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
        <Typography variant="h6" align="center" color="error">
          Please login as a farmer to add products
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
          <Button variant="contained" onClick={() => navigate('/login')}>
            Go to Login
          </Button>
        </Box>
      </Paper>
    );
  }

  if (user.role !== 'farmer') {
    return (
      <Paper elevation={3} sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
        <Typography variant="h6" align="center" color="error">
          Only farmers can add products
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
          <Button variant="contained" onClick={() => navigate('/')}>
            Go to Home
          </Button>
        </Box>
      </Paper>
    );
  }

  return (
    <Paper elevation={3} sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="h6" gutterBottom>
              Product Details
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Product Name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              error={!!errors.name}
              helperText={errors.name}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl fullWidth required>
              <InputLabel>Category</InputLabel>
              <Select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                error={!!errors.category}
              >
                <MenuItem value="">Select Category</MenuItem>
                <MenuItem value="Vegetables">Vegetables</MenuItem>
                <MenuItem value="Fruits">Fruits</MenuItem>
                <MenuItem value="Grains">Grains</MenuItem>
                <MenuItem value="Dairy">Dairy</MenuItem>
                <MenuItem value="Meat">Meat</MenuItem>
                <MenuItem value="Poultry">Poultry</MenuItem>
                <MenuItem value="Organic">Organic</MenuItem>
                <MenuItem value="Others">Others</MenuItem>
              </Select>
              {errors.category && (
                <FormHelperText error>{errors.category}</FormHelperText>
              )}
            </FormControl>
          </Grid>

          <Grid item xs={12}>
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              error={!!errors.description}
              helperText={errors.description}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              type="number"
              label="Price"
              name="price"
              value={formData.price}
              onChange={handleInputChange}
              required
              InputProps={{
                startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              }}
              error={!!errors.price}
              helperText={errors.price}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              type="number"
              label="Quantity"
              name="quantity"
              value={formData.quantity}
              onChange={handleInputChange}
              required
              error={!!errors.quantity}
              helperText={errors.quantity}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl fullWidth required>
              <InputLabel>Unit</InputLabel>
              <Select
                name="unit"
                value={formData.unit}
                onChange={handleInputChange}
                error={!!errors.unit}
              >
                <MenuItem value="">Select Unit</MenuItem>
                <MenuItem value="kg">Kilogram (kg)</MenuItem>
                <MenuItem value="g">Gram (g)</MenuItem>
                <MenuItem value="l">Litre (l)</MenuItem>
                <MenuItem value="ml">Millilitre (ml)</MenuItem>
                <MenuItem value="piece">Piece</MenuItem>
                <MenuItem value="dozen">Dozen</MenuItem>
              </Select>
              {errors.unit && (
                <FormHelperText error>{errors.unit}</FormHelperText>
              )}
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Location"
              name="location"
              value={formData.location}
              onChange={handleInputChange}
              required
              error={!!errors.location}
              helperText={errors.location}
            />
          </Grid>

          <Grid item xs={12}>
            <Typography variant="subtitle1" gutterBottom>
              Product Image
            </Typography>
            <Box sx={{ mb: 2, display: 'flex', gap: 2, alignItems: 'center' }}>
              <Button
                variant="contained"
                onClick={generateAIImage}
                disabled={!formData.name || !formData.category || isGeneratingImage}
                startIcon={<AutoFixHigh />}
              >
                {isGeneratingImage ? 'Generating...' : 'Generate AI Image'}
              </Button>
              
              <Box>
                <input
                  accept="image/*"
                  type="file"
                  id="image-upload"
                  onChange={handleImageChange}
                  style={{ display: 'none' }}
                />
                <label htmlFor="image-upload">
                  <Button
                    variant="outlined"
                    component="span"
                    startIcon={<CloudUpload />}
                  >
                    Upload Image
                  </Button>
                </label>
              </Box>
            </Box>
            
            {formData.imagePreview && (
              <Box sx={{ mt: 2, position: 'relative' }}>
                <img
                  src={formData.imagePreview}
                  alt="Product preview"
                  style={{
                    width: '100%',
                    maxHeight: '300px',
                    objectFit: 'contain',
                    borderRadius: '4px',
                  }}
                />
                <Button
                  size="small"
                  color="error"
                  onClick={() => setFormData(prev => ({
                    ...prev,
                    image: null,
                    imagePreview: null
                  }))}
                  sx={{
                    position: 'absolute',
                    top: 8,
                    right: 8,
                    backgroundColor: 'rgba(255, 255, 255, 0.8)',
                    '&:hover': {
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    }
                  }}
                >
                  Remove
                </Button>
              </Box>
            )}
          </Grid>

          <Grid item xs={12}>
            <Button
              type="submit"
              variant="contained"
              fullWidth
              size="large"
              disabled={loading || isGeneratingImage}
              startIcon={loading ? <CircularProgress size={20} /> : <Add />}
              // sx={{
              //   backgroundColor: 'red',   // <-- your desired background color
                
              // }}
            >
              {loading ? 'Adding Product...' : 'Add Products'}
            </Button>
          </Grid>
        </Grid>
      </form>

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
      >
        <Alert
          onClose={() => setNotification({ ...notification, open: false })}
          severity={notification.severity}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
};

export default AddProductForm;
