import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Grid,
  Paper,
  Snackbar,
  Alert,
  CircularProgress,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { Agriculture } from '@mui/icons-material';

const PreBookingForm = ({ farmer }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    crop: '',
    variety: '',
    quantity: '',
    unit: 'kg',
    expectedHarvestDate: '',
    pricePerUnit: '',
  });
  const [loading, setLoading] = useState(false);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate form data
      if (!formData.crop || !formData.variety || !formData.quantity || !formData.expectedHarvestDate || !formData.pricePerUnit) {
        throw new Error('Please fill in all required fields');
      }

      const response = await axios.post('http://localhost:5001/api/pre-orders', {
        ...formData,
        farmer: farmer._id
      }, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      const preOrder = response.data.preOrder;
      
      // Initialize Razorpay
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      document.body.appendChild(script);

      script.onload = () => {
        const options = {
          key: process.env.REACT_APP_RAZORPAY_KEY, // Replace with your Razorpay key
          amount: response.data.payment.amount,
          currency: "INR",
          name: "Ashi Farmer",
          description: `Deposit for ${formData.crop} pre-order`,
          order_id: response.data.payment.id,
          handler: async function (response) {
            try {
              setPaymentLoading(true);
              // Verify payment with backend
              const verifyResponse = await axios.post('http://localhost:5001/api/pre-orders/payment/verify', {
                razorpayPaymentId: response.razorpay_payment_id,
                razorpayOrderId: response.razorpay_order_id,
                razorpaySignature: response.razorpay_signature,
                preOrderId: preOrder._id,
              }, {
                headers: {
                  'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
              });

              if (verifyResponse.data.success) {
                navigate('/pre-orders', { state: { preOrder } });
              } else {
                throw new Error('Payment verification failed');
              }
            } catch (error) {
              console.error('Error verifying payment:', error);
              setSnackbar({
                open: true,
                message: 'Payment verification failed. Please try again.',
                severity: 'error',
              });
            } finally {
              setPaymentLoading(false);
            }
          },
          prefill: {
            name: user.name,
            email: user.email,
            contact: user.phone,
          },
          theme: {
            color: '#4CAF50',
          },
        };

        const rzp = new window.Razorpay(options);
        rzp.open();
      };

      script.onerror = () => {
        throw new Error('Failed to load Razorpay script');
      };
    } catch (error) {
      console.error('Error placing pre-order:', error);
      setSnackbar({
        open: true,
        message: error.message || 'Failed to place pre-order',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  return (
    <Box>
      <Paper sx={{ p: 3, bgcolor: 'background.paper' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Agriculture fontSize="large" sx={{ mr: 1, color: 'primary.main' }} />
          <Typography variant="h5" gutterBottom>
            Pre-Book Crop
          </Typography>
        </Box>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Crop Name"
                name="crop"
                value={formData.crop}
                onChange={handleChange}
                variant="outlined"
                size="medium"
                sx={{ bgcolor: 'background.paper' }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Variety"
                name="variety"
                value={formData.variety}
                onChange={handleChange}
                variant="outlined"
                size="medium"
                sx={{ bgcolor: 'background.paper' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Quantity"
                name="quantity"
                type="number"
                value={formData.quantity}
                onChange={handleChange}
                variant="outlined"
                size="medium"
                InputProps={{
                  inputProps: { min: 1 }
                }}
                sx={{ bgcolor: 'background.paper' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth variant="outlined" size="medium" sx={{ bgcolor: 'background.paper' }}>
                <InputLabel>Unit</InputLabel>
                <Select
                  required
                  name="unit"
                  value={formData.unit}
                  onChange={handleChange}
                  label="Unit"
                  size="medium"
                >
                  <MenuItem value="kg">Kilograms (kg)</MenuItem>
                  <MenuItem value="quintal">Quintals</MenuItem>
                  <MenuItem value="tonne">Tonnes</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Expected Harvest Date"
                name="expectedHarvestDate"
                type="date"
                value={formData.expectedHarvestDate}
                onChange={handleChange}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                size="medium"
                sx={{ bgcolor: 'background.paper' }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Price per Unit (₹)"
                name="pricePerUnit"
                type="number"
                value={formData.pricePerUnit}
                onChange={handleChange}
                variant="outlined"
                size="medium"
                InputProps={{
                  inputProps: { min: 0 }
                }}
                sx={{ bgcolor: 'background.paper' }}
              />
            </Grid>
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
                disabled={loading || paymentLoading}
                startIcon={loading || paymentLoading ? <CircularProgress size={24} /> : null}
                sx={{
                  mt: 2,
                  height: 50,
                  fontSize: '1rem'
                }}
              >
                {loading || paymentLoading ? 'Processing...' : 'Place Pre-Order'}
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default PreBookingForm;
