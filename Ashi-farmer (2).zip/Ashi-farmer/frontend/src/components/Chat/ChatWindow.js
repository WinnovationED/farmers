import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Paper,
  TextField,
  IconButton,
  Typography,
  List,
  ListItem,
  ListItemText,
  Divider,
  CircularProgress,
  Alert
} from '@mui/material';
import { Send as SendIcon } from '@mui/icons-material';
import { formatDistanceToNow } from 'date-fns';
import io from 'socket.io-client';

const SOCKET_URL = 'http://localhost:5000';

const ChatWindow = ({ currentUser, otherUser, product, onClose }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const [socket, setSocket] = useState(null);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!currentUser?._id) return;

    // Initialize socket connection
    const newSocket = io(SOCKET_URL);
    setSocket(newSocket);

    // Join the chat
    newSocket.emit('join', currentUser._id);

    // Fetch existing messages
    fetchMessages();

    return () => {
      newSocket.close();
    };
  }, [currentUser?._id]);

  useEffect(() => {
    if (!socket || !otherUser?._id) return;

    // Listen for new messages
    socket.on('new_message', ({ message }) => {
      setMessages(prev => [...prev, message]);
      scrollToBottom();
    });

    // Listen for typing indicators
    socket.on('user_typing', ({ senderId }) => {
      if (senderId === otherUser._id) {
        setIsTyping(true);
        setTimeout(() => setIsTyping(false), 3000);
      }
    });

    return () => {
      socket.off('new_message');
      socket.off('user_typing');
    };
  }, [socket, otherUser?._id]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    if (!currentUser?._id || !otherUser?._id || !product?._id) return;
    
    try {
      const response = await fetch(
        `/api/chat/messages/${product._id}/${currentUser._id}/${otherUser._id}`
      );
      if (!response.ok) throw new Error('Failed to fetch messages');
      const data = await response.json();
      setMessages(data);
      setLoading(false);
    } catch (err) {
      setError('Failed to load messages');
      setLoading(false);
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !socket) return;

    try {
      socket.emit('private_message', {
        senderId: currentUser._id,
        receiverId: otherUser._id,
        productId: product._id,
        content: newMessage
      });

      setNewMessage('');
    } catch (err) {
      setError('Failed to send message');
    }
  };

  const handleTyping = () => {
    if (!socket) return;
    
    socket.emit('typing', {
      senderId: currentUser._id,
      receiverId: otherUser._id,
      productId: product._id
    });
  };

  // Check if required props are available
  if (!currentUser?._id || !otherUser?._id || !product?._id) {
    return (
      <Paper elevation={3} sx={{ p: 3 }}>
        <Alert severity="error">Missing required information to load chat</Alert>
      </Paper>
    );
  }

  if (loading) return <CircularProgress />;
  if (error) return <Alert severity="error">{error}</Alert>;

  return (
    <Paper elevation={3} sx={{ height: '500px', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Box sx={{ p: 2, bgcolor: 'primary.main', color: 'white' }}>
        <Typography variant="h6">
          Chat with {otherUser.name} about {product.name}
        </Typography>
      </Box>

      {/* Messages */}
      <Box sx={{ flex: 1, overflow: 'auto', p: 2 }}>
        <List>
          {messages.map((message, index) => (
            <React.Fragment key={message._id}>
              <ListItem
                sx={{
                  flexDirection: 'column',
                  alignItems: message.sender === currentUser._id ? 'flex-end' : 'flex-start'
                }}
              >
                <Paper
                  elevation={1}
                  sx={{
                    p: 1,
                    bgcolor: message.sender === currentUser._id ? 'primary.light' : 'grey.100',
                    maxWidth: '70%'
                  }}
                >
                  <Typography variant="body1">{message.content}</Typography>
                  <Typography variant="caption" color="textSecondary">
                    {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                  </Typography>
                </Paper>
              </ListItem>
              {index < messages.length - 1 && <Divider variant="middle" />}
            </React.Fragment>
          ))}
          {isTyping && (
            <ListItem>
              <Typography variant="body2" color="textSecondary" fontStyle="italic">
                {otherUser.name} is typing...
              </Typography>
            </ListItem>
          )}
          <div ref={messagesEndRef} />
        </List>
      </Box>

      {/* Message Input */}
      <Box sx={{ p: 2, bgcolor: 'background.paper' }}>
        <form onSubmit={handleSend} style={{ display: 'flex', gap: 8 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleTyping}
            size="small"
          />
          <IconButton type="submit" color="primary" disabled={!newMessage.trim()}>
            <SendIcon />
          </IconButton>
        </form>
      </Box>
    </Paper>
  );
};

export default ChatWindow;
