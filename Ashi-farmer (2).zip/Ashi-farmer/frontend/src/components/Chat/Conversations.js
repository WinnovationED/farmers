import React, { useState, useEffect } from 'react';
import {
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Typography,
  Paper,
  Badge,
  Divider,
  CircularProgress,
  Alert
} from '@mui/material';
import { formatDistanceToNow } from 'date-fns';
import { Person as PersonIcon } from '@mui/icons-material';

const Conversations = ({ currentUser, onSelectConversation }) => {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchConversations();
  }, [currentUser._id]);

  const fetchConversations = async () => {
    try {
      const response = await fetch(`/api/chat/conversations/${currentUser._id}`);
      if (!response.ok) throw new Error('Failed to fetch conversations');
      const data = await response.json();
      setConversations(data);
      setLoading(false);
    } catch (err) {
      setError('Failed to load conversations');
      setLoading(false);
    }
  };

  if (loading) return <CircularProgress />;
  if (error) return <Alert severity="error">{error}</Alert>;

  return (
    <Paper elevation={3}>
      <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
        {conversations.map((conversation, index) => (
          <React.Fragment key={conversation._id}>
            <ListItem
              button
              onClick={() => onSelectConversation(conversation)}
              alignItems="flex-start"
            >
              <ListItemAvatar>
                <Badge
                  color="primary"
                  variant="dot"
                  invisible={conversation.lastMessage.read}
                >
                  <Avatar>
                    <PersonIcon />
                  </Avatar>
                </Badge>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Typography
                    component="span"
                    variant="body1"
                    color="text.primary"
                  >
                    {conversation.user.name}
                  </Typography>
                }
                secondary={
                  <React.Fragment>
                    <Typography
                      component="span"
                      variant="body2"
                      color="text.primary"
                    >
                      {conversation.product.name}
                    </Typography>
                    {" — "}
                    <Typography
                      component="span"
                      variant="body2"
                      color="text.secondary"
                    >
                      {conversation.lastMessage.content.substring(0, 30)}
                      {conversation.lastMessage.content.length > 30 ? "..." : ""}
                    </Typography>
                    <Typography
                      component="span"
                      variant="caption"
                      color="text.secondary"
                      display="block"
                    >
                      {formatDistanceToNow(new Date(conversation.lastMessage.createdAt), { addSuffix: true })}
                    </Typography>
                  </React.Fragment>
                }
              />
            </ListItem>
            {index < conversations.length - 1 && <Divider variant="inset" component="li" />}
          </React.Fragment>
        ))}
      </List>
    </Paper>
  );
};

export default Conversations;
