import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
  IconButton,
  Tooltip,
  Stack,
  Snackbar,
  Alert,
  CircularProgress,
  Rating,
  Chip,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  Favorite,
  FavoriteBorder,
  ShoppingCart,
  ShoppingCartCheckout,
  LocationOn,
  Verified,
  LocalOffer,
  Timer,
  Star,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';

const ProductCard = ({ product, onAddToFavorites, isFavorite }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart, cartItems, loading } = useCart();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const isInCart = cartItems?.some(item => item.product._id === product._id);

  const handleBuyNow = () => {
    if (!user) {
      navigate('/login', { state: { from: '/products' } });
      return;
    }
    if (user.role === 'farmer') {
      setSnackbar({
        open: true,
        message: 'Farmers cannot purchase products',
        severity: 'error'
      });
      return;
    }

    // Navigate to checkout with product details
    navigate('/checkout', { 
      state: { 
        product: {
          _id: product._id,
          name: product.name,
          price: product.price,
          imageUrl: product.imageUrl,
          seller: product.seller
        },
        quantity: 1,
        totalAmount: product.price
      } 
    });
  };

  const handleAddToCart = async () => {
    try {
      if (!user) {
        navigate('/login', { state: { from: '/products' } });
        return;
      }
      if (user.role === 'farmer') {
        setSnackbar({
          open: true,
          message: 'Farmers cannot add items to cart',
          severity: 'error'
        });
        return;
      }

      setIsAddingToCart(true);

      // Check if product is already in cart
      if (isInCart) {
        navigate('/cart');
        return;
      }

      // Add to cart
      await addToCart(product, 1);
      setSnackbar({
        open: true,
        message: 'Added to cart successfully!',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error adding to cart:', error);
      let errorMessage = 'Failed to add to cart';
      
      // Handle specific error cases
      if (error.message?.includes('Insufficient stock')) {
        errorMessage = `Only ${error.availableQuantity} units available`;
      } else if (error.message?.includes('Cannot add your own products')) {
        errorMessage = 'You cannot add your own products to cart';
      }
      
      setSnackbar({
        open: true,
        message: errorMessage,
        severity: 'error'
      });
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  return (
    <>
      <Card
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
          transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: (theme) => theme.shadows[8],
          },
          border: '1px solid rgba(0, 0, 0, 0.1)',
          willChange: 'transform, box-shadow',
          backfaceVisibility: 'hidden',
        }}
      >
        {/* Product Tags */}
        <Box
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            display: 'flex',
            gap: 1,
            zIndex: 1,
          }}
        >
          {product.isOrganic && (
            <Chip
              label="Organic"
              color="success"
              size="small"
              icon={<Verified sx={{ fontSize: 14 }} />}
              sx={{
                '& .MuiChip-label': {
                  fontSize: '0.75rem',
                },
              }}
            />
          )}
          {product.isNew && (
            <Chip
              label="New"
              color="primary"
              size="small"
              sx={{
                '& .MuiChip-label': {
                  fontSize: '0.75rem',
                },
              }}
            />
          )}
        </Box>

        {/* Product Image */}
        <CardMedia
          component="img"
          height="200"
          image={product.imageUrl && product.imageUrl.startsWith('/') 
            ? `http://localhost:5001${product.imageUrl}`
            : product.imageUrl || 'https://via.placeholder.com/300'}
          alt={product.name}
          sx={{ 
            objectFit: 'cover',
            transition: 'opacity 0.3s ease-in-out',
            '&:hover': {
              opacity: 0.9,
            },
          }}
        />

        {/* Product Details */}
        <CardContent sx={{ flexGrow: 1, p: 2 }}>
          <Stack spacing={1}>
            {/* Product Name and Rating */}
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Typography 
                variant="h6" 
                component="h2" 
                sx={{ 
                  fontWeight: 600,
                  mb: 1,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                }}
              >
                {product.name}
              </Typography>
              <Rating
                value={product.rating || 0}
                precision={0.5}
                readOnly
                size="small"
                sx={{ color: theme.palette.warning.main }}
              />
            </Stack>

            {/* Product Description */}
            <Typography 
              variant="body2" 
              color="text.secondary" 
              sx={{ 
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
                mb: 1,
              }}
            >
              {product.description}
            </Typography>

            {/* Price and Stock */}
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <Typography 
                variant="h6" 
                color="primary" 
                sx={{ 
                  fontWeight: 600,
                  mb: 1,
                }}
              >
                ₹{product.price}
              </Typography>
              <Chip
                label={`${product.quantity} units available`}
                color={product.quantity > 0 ? 'success' : 'error'}
                size="small"
                icon={
                  product.quantity > 0 ? (
                    <LocalOffer sx={{ fontSize: 14 }} />
                  ) : (
                    <Timer sx={{ fontSize: 14 }} />
                  )
                }
                sx={{
                  '& .MuiChip-label': {
                    fontSize: '0.75rem',
                  },
                }}
              />
            </Stack>

            {/* Location */}
            <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
              <LocationOn sx={{ color: 'text.secondary', fontSize: 16 }} />
              <Typography variant="body2" color="text.secondary">
                {product.location}
              </Typography>
            </Stack>
          </Stack>
        </CardContent>

        {/* Action Buttons */}
        <Box sx={{ p: 2 }}>
          <Stack spacing={1}>
            <Button
              variant="contained"
              fullWidth
              onClick={handleBuyNow}
              startIcon={<ShoppingCartCheckout />}
              disabled={!product.quantity || (user && user.role === 'farmer')}
              color="primary"
              sx={{
                borderRadius: 2,
                textTransform: 'none',
                fontSize: '0.9rem',
                transition: 'transform 0.2s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-1px)',
                },
              }}
            >
              Buy Now
            </Button>

            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <Button
                variant={isInCart ? "contained" : "outlined"}
                onClick={handleAddToCart}
                startIcon={isAddingToCart ? <CircularProgress size={20} /> : <ShoppingCart />}
                disabled={!product.quantity || (user && user.role === 'farmer') || isAddingToCart}
                color={isInCart ? "success" : "primary"}
                sx={{
                  flex: 1,
                  minWidth: 0,
                  textTransform: 'none',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  borderRadius: 2,
                  fontSize: '0.9rem',
                }}
              >
                {isInCart ? 'Go to Cart' : 'Add to Cart'}
              </Button>

              {user && user.role === 'buyer' && (
                <Tooltip title={isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}>
                  <IconButton
                    color={isFavorite ? 'primary' : 'default'}
                    onClick={() => onAddToFavorites(product._id)}
                    size="small"
                    sx={{
                      borderRadius: '50%',
                      transition: 'transform 0.2s ease-in-out',
                      '&:hover': {
                        transform: 'scale(1.1)',
                      },
                    }}
                  >
                    {isFavorite ? <Favorite /> : <FavoriteBorder />}
                  </IconButton>
                </Tooltip>
              )}
            </Box>
          </Stack>
        </Box>
      </Card>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{
            width: '100%',
            maxWidth: 600,
            fontSize: '0.9rem',
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default ProductCard;
