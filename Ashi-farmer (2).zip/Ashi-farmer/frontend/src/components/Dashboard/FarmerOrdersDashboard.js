import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Menu,
  MenuItem,
  Button,
  Alert,
  CircularProgress,
  Tooltip
} from '@mui/material';
import {
  MoreVert as MoreVertIcon,
  CalendarMonth as CalendarIcon,
  Star as StarIcon
} from '@mui/icons-material';
import { Calendar, dateFnsLocalizer } from 'react-big-calendar';
import { format, parse, startOfWeek, getDay } from 'date-fns';
import enUS from 'date-fns/locale/en-US';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Link } from 'react-router-dom';

const locales = {
  'en-US': enUS
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales
});

const statusColors = {
  pending: 'warning',
  confirmed: 'info',
  cancelled: 'error',
  delivered: 'success'
};

const FarmerOrdersDashboard = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'calendar'
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      setError(null);
      console.log('Fetching farmer orders...');
      const response = await fetch('http://localhost:5000/api/orders/farmer-orders');
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        throw new Error('Failed to fetch orders');
      }
      
      const data = await response.json();
      console.log('Fetched orders:', data);
      setOrders(data);
    } catch (err) {
      console.error('Error fetching orders:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (orderId, newStatus) => {
    try {
      setError(null);
      console.log('Updating order status:', orderId, newStatus);
      const response = await fetch(`http://localhost:5000/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: newStatus })
      });

      console.log('Update response status:', response.status);
      
      if (!response.ok) {
        throw new Error('Failed to update order status');
      }
      
      const updatedOrder = await response.json();
      console.log('Updated order:', updatedOrder);
      
      setOrders(orders.map(order => 
        order._id === updatedOrder._id ? updatedOrder : order
      ));
    } catch (err) {
      console.error('Error updating order:', err);
      setError(err.message);
    }
    handleCloseMenu();
  };

  const handleOpenMenu = (event, order) => {
    setAnchorEl(event.currentTarget);
    setSelectedOrder(order);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
    setSelectedOrder(null);
  };

  const calendarEvents = orders.map(order => ({
    id: order._id,
    title: `${order.product?.name || 'Unknown Product'} (${order.quantity}${order.unit})`,
    start: new Date(order.deliveryDate),
    end: new Date(order.deliveryDate),
    resource: order
  }));

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '200px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 2 }}>
        <Alert 
          severity="error" 
          action={
            <Button color="inherit" size="small" onClick={fetchOrders}>
              Retry
            </Button>
          }
        >
          {error}
        </Alert>
      </Box>
    );
  }

  if (orders.length === 0) {
    return (
      <Box sx={{ p: 2 }}>
        <Alert severity="info">
          No orders found. Orders will appear here when customers place them.
        </Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Order Management</Typography>
        <Button
          variant="outlined"
          startIcon={viewMode === 'table' ? <CalendarIcon /> : null}
          onClick={() => setViewMode(viewMode === 'table' ? 'calendar' : 'table')}
        >
          {viewMode === 'table' ? 'Calendar View' : 'Table View'}
        </Button>
      </Box>

      {viewMode === 'table' ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Product</TableCell>
                <TableCell>Buyer</TableCell>
                <TableCell>Quantity</TableCell>
                <TableCell>Delivery Date</TableCell>
                <TableCell>Total Price</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order._id}>
                  <TableCell>{order.product?.name || 'Unknown Product'}</TableCell>
                  <TableCell>{order.buyer?.name || 'Unknown Buyer'}</TableCell>
                  <TableCell>{order.quantity} {order.unit}</TableCell>
                  <TableCell>{format(new Date(order.deliveryDate), 'PP')}</TableCell>
                  <TableCell>₹{order.totalPrice}</TableCell>
                  <TableCell>
                    <Chip
                      label={order.status}
                      color={statusColors[order.status] || 'default'}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <IconButton onClick={(e) => handleOpenMenu(e, order)}>
                        <MoreVertIcon />
                      </IconButton>
                      <Tooltip title="View Ratings">
                        <Button
                          component={Link}
                          to={`/orders/${order._id}/ratings`}
                          startIcon={<StarIcon />}
                          size="small"
                        >
                          Ratings
                        </Button>
                      </Tooltip>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <Paper sx={{ p: 2, height: 600 }}>
          <Calendar
            localizer={localizer}
            events={calendarEvents}
            startAccessor="start"
            endAccessor="end"
            style={{ height: '100%' }}
            onSelectEvent={(event) => {
              setSelectedOrder(event.resource);
              setAnchorEl(document.getElementById('calendar-view'));
            }}
          />
        </Paper>
      )}

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseMenu}
      >
        <MenuItem 
          onClick={() => handleStatusUpdate(selectedOrder?._id, 'confirmed')}
          disabled={selectedOrder?.status === 'confirmed'}
        >
          Confirm Order
        </MenuItem>
        <MenuItem 
          onClick={() => handleStatusUpdate(selectedOrder?._id, 'delivered')}
          disabled={selectedOrder?.status === 'delivered'}
        >
          Mark as Delivered
        </MenuItem>
        <MenuItem 
          onClick={() => handleStatusUpdate(selectedOrder?._id, 'cancelled')}
          disabled={selectedOrder?.status === 'cancelled'}
        >
          Cancel Order
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default FarmerOrdersDashboard;
