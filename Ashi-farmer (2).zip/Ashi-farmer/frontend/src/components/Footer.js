import React from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Link,
  IconButton,
  useTheme,
  useMediaQuery,
  Paper,
  Button,
  Divider,
  Stack,
} from '@mui/material';
import {
  Facebook,
  Instagram,
  Twitter,
  WhatsApp,
  Mail,
  Phone,
  LocationOn,
  Copyright,
  ArrowUpward,
} from '@mui/icons-material';
import Aos from 'aos';
import 'aos/dist/aos.css';

const Footer = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  // Initialize AOS (Animate On Scroll)
  React.useEffect(() => {
    Aos.init({
      duration: 1000,
      easing: 'ease-out',
      once: true,
      offset: 50,
    });
  }, []);

  const socialLinks = [
    { icon: <Facebook />, url: '#' },
    { icon: <Instagram />, url: '#' },
    { icon: <Twitter />, url: '#' },
    { icon: <WhatsApp />, url: '#' },
  ];

  const quickLinks = [
    { title: 'About Us', url: '/about' },
    { title: 'How It Works', url: '/how-it-works' },
    { title: 'Blog', url: '/blog' },
    { title: 'FAQ', url: '/faq' },
    { title: 'Contact', url: '/contact' },
  ];

  const contactInfo = [
    {
      icon: <LocationOn />,
      label: '123 Farming Street, Agri City, 123456',
    },
    {
      icon: <Phone />,
      label: '+91 123 456 7890',
    },
    {
      icon: <Mail />,
      label: 'sarwar@farmer.com',
    },
  ];

  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: theme.palette.background.default,
        color: theme.palette.text.primary,
        mt: 'auto',
      }}
    >
      {/* Main Footer Content */}
      <Container maxWidth="lg" sx={{ pt: 8, pb: 4 }}>
        <Grid container spacing={4}>
          {/* Quick Links */}
          <Grid item xs={12} sm={6} md={3} data-aos="fade-up">
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Quick Links
            </Typography>
            <Stack spacing={2}>
              {quickLinks.map((link) => (
                <Link
                  key={link.title}
                  href={link.url}
                  color="inherit"
                  underline="hover"
                  sx={{
                    display: 'block',
                    transition: 'color 0.3s ease',
                    '&:hover': {
                      color: theme.palette.primary.main,
                    },
                  }}
                >
                  {link.title}
                </Link>
              ))}
            </Stack>
          </Grid>

          {/* Contact Info */}
          <Grid item xs={12} sm={6} md={3} data-aos="fade-up" data-aos-delay="100">
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Contact Us
            </Typography>
            <Stack spacing={2}>
              {contactInfo.map((info) => (
                <Stack
                  key={info.label}
                  direction="row"
                  alignItems="center"
                  spacing={1}
                >
                  {info.icon}
                  <Typography variant="body2">{info.label}</Typography>
                </Stack>
              ))}
            </Stack>
          </Grid>

          {/* Social Links */}
          <Grid item xs={12} sm={6} md={3} data-aos="fade-up" data-aos-delay="200">
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Follow Us
            </Typography>
            <Stack direction={isMobile ? 'column' : 'row'} spacing={2}>
              {socialLinks.map((social) => (
                <IconButton
                  key={social.url}
                  href={social.url}
                  target="_blank"
                  color="inherit"
                  size="large"
                  sx={{
                    transition: 'transform 0.3s ease',
                    '&:hover': {
                      transform: 'scale(1.2)',
                      color: theme.palette.primary.main,
                    },
                  }}
                >
                  {social.icon}
                </IconButton>
              ))}
            </Stack>
          </Grid>

          {/* Newsletter */}
          <Grid item xs={12} sm={6} md={3} data-aos="fade-up" data-aos-delay="300">
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              Newsletter
            </Typography>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Subscribe to our newsletter for the latest updates
            </Typography>
            <Paper
              component="form"
              onSubmit={(e) => e.preventDefault()}
              sx={{
                p: 2,
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                gap: 1,
              }}
            >
              <input
                type="email"
                placeholder="Enter your email"
                required
                style={{
                  flex: 1,
                  padding: '8px 12px',
                  border: '1px solid rgba(0, 0, 0, 0.1)',
                  borderRadius: '4px',
                  fontSize: '0.9rem',
                }}
              />
              <Button
                type="submit"
                variant="contained"
                color="primary"
                sx={{
                  minWidth: 100,
                  textTransform: 'none',
                  fontSize: '0.9rem',
                }}
              >
                Subscribe
              </Button>
            </Paper>
          </Grid>
        </Grid>
      </Container>

      {/* Bottom Bar */}
      <Box
        sx={{
          borderTop: `1px solid ${theme.palette.divider}`,
          backgroundColor: theme.palette.background.paper,
          py: 2,
        }}
      >
        <Container maxWidth="lg">
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={6}>
              <Typography variant="body2" color="text.secondary">
                <Copyright sx={{ fontSize: '1rem', mr: 0.5 }} />
                {new Date().getFullYear()} Ashi Farmer. All rights reserved.
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Stack
                direction="row"
                justifyContent="flex-end"
                spacing={2}
                alignItems="center"
              >
                <Button
                  variant="text"
                  color="inherit"
                  startIcon={<ArrowUpward />}
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                  sx={{
                    textTransform: 'none',
                    fontSize: '0.9rem',
                    '&:hover': {
                      color: theme.palette.primary.main,
                    },
                  }}
                >
                  Back to top
                </Button>
              </Stack>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default Footer;
