import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Grid,
  Card,
  CardMedia,
  CardContent,
  CardActions,
  Typography,
  Button,
  Chip,
  Box,
  Dialog,
  DialogContent,
  Container,
  TextField,
  IconButton,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { CalendarToday as CalendarIcon, LocationOn, Category, ShoppingCart, Message } from '@mui/icons-material';
import axios from 'axios';
import Checkout from './Checkout';
import ChatWindow from './Chat/ChatWindow';

const categories = ['All', 'Vegetables', 'Fruits', 'Grains', 'Dairy', 'Poultry', 'Meat', 'Organic', 'Others'];

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('http://localhost:5001/api/products');
      
      if (!response.ok) {
        throw new Error('Failed to fetch products');
      }
      
      const data = await response.json();
      setProducts(data);
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleBuyNow = (product) => {
    setSelectedProduct(product);
    setShowCheckout(true);
  };

  const handleChat = (product) => {
    setSelectedProduct(product);
    setShowChat(true);
  };

  const handleCloseChat = () => {
    setShowChat(false);
    setSelectedProduct(null);
  };

  const handleCloseCheckout = () => {
    setShowCheckout(false);
    setSelectedProduct(null);
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '200px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 2 }}>
        <Alert severity="error">
          {error}
          <Button color="inherit" size="small" onClick={fetchProducts} sx={{ ml: 2 }}>
            Retry
          </Button>
        </Alert>
      </Box>
    );
  }

  if (products.length === 0) {
    return (
      <Box sx={{ p: 2 }}>
        <Alert severity="info">
          No products available yet. Check back later!
        </Alert>
      </Box>
    );
  }

  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={8}>
            <TextField
              fullWidth
              variant="outlined"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Category</InputLabel>
              <Select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                label="Category"
              >
                {categories.map((category) => (
                  <MenuItem key={category} value={category}>
                    {category}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Box>

      <Grid container spacing={3}>
        {filteredProducts.map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product._id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardMedia
                component="img"
                height="200"
                image={product.imageUrl || 'https://via.placeholder.com/300x200?text=Product+Image'}
                alt={product.name}
              />
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="h2">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  {product.description}
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6" color="primary">
                    ₹{product.price}/{product.unit}
                  </Typography>
                  <Chip
                    label={`Available: ${product.quantity} ${product.unit}`}
                    color="success"
                    size="small"
                  />
                </Box>
                <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                  <Chip
                    icon={<Category />}
                    label={product.category}
                    size="small"
                  />
                  <Chip
                    icon={<LocationOn />}
                    label={product.location}
                    size="small"
                  />
                </Box>
                <Typography variant="body2" color="text.secondary">
                  Farmer: {product.farmer?.name || 'Unknown'}
                </Typography>
              </CardContent>
              <CardActions sx={{ flexDirection: 'column', p: 2 }}>
                <Button
                  component={Link}
                  to={`/pre-book/${product._id}`}
                  variant="contained"
                  color="primary"
                  startIcon={<CalendarIcon />}
                  fullWidth
                >
                  Pre-book Now
                </Button>
                <Box sx={{ display: 'flex', gap: 1, width: '100%', mt: 1 }}>
                  <Button 
                    color="primary"
                    variant="outlined"
                    startIcon={<ShoppingCart />}
                    onClick={() => handleBuyNow(product)}
                    sx={{ flex: 1 }}
                  >
                    Buy Now
                  </Button>
                  <Button
                    variant="outlined"
                    startIcon={<Message />}
                    onClick={() => handleChat(product)}
                    sx={{ flex: 1 }}
                  >
                    Chat
                  </Button>
                </Box>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Checkout Dialog */}
      <Dialog open={showCheckout} onClose={handleCloseCheckout} maxWidth="sm" fullWidth>
        <DialogContent>
          {selectedProduct && <Checkout product={selectedProduct} onClose={handleCloseCheckout} />}
        </DialogContent>
      </Dialog>

      {/* Chat Dialog */}
      <Dialog open={showChat} onClose={handleCloseChat} maxWidth="sm" fullWidth>
        <DialogContent>
          {selectedProduct && <ChatWindow product={selectedProduct} onClose={handleCloseChat} />}
        </DialogContent>
      </Dialog>
    </Container>
  );
};

export default ProductList;
