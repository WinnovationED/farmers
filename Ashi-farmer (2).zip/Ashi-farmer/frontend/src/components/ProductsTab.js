import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  InputAdornment,
  Chip,
  Paper,
  Fab,
  Tooltip,
  Alert,
  CircularProgress,
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  Search,
  FilterList,
  AddPhotoAlternate,
  Save,
} from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

const ProductsTab = () => {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  const categories = ['Vegetables', 'Fruits', 'Grains', 'Dairy'];

  // Initialize with some dummy data while backend connection is established
  const dummyProducts = [
    {
      _id: '1',
      name: 'Fresh Tomatoes',
      price: 40,
      stock: 100,
      category: 'Vegetables',
      image: 'https://source.unsplash.com/random/400x300/?tomato',
      description: 'Fresh, ripe tomatoes from local farms',
    },
    {
      _id: '2',
      name: 'Organic Potatoes',
      price: 30,
      stock: 150,
      category: 'Vegetables',
      image: 'https://source.unsplash.com/random/400x300/?potato',
      description: 'Locally grown organic potatoes',
    },
  ];

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      // First try to fetch from backend
      try {
        const response = await fetch('http://localhost:5001/api/products', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        if (response.ok) {
          const data = await response.json();
          setProducts(data);
          return;
        }
      } catch (err) {
        console.log('Backend not connected, using dummy data:', err);
      }
      
      // If backend fails, use dummy data
      setProducts(dummyProducts);
    } catch (err) {
      setError('Error loading products: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = () => {
    setEditProduct(null);
    setOpenDialog(true);
    setError(null);
  };

  const handleEditProduct = (product) => {
    setEditProduct(product);
    setOpenDialog(true);
    setError(null);
  };

  const handleDeleteProduct = async (productId) => {
    try {
      // Try backend first
      try {
        const response = await fetch(`http://localhost:5001/api/products/${productId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        if (response.ok) {
          setProducts(products.filter(p => p._id !== productId));
          setSuccessMessage('Product deleted successfully');
          setTimeout(() => setSuccessMessage(''), 3000);
          return;
        }
      } catch (err) {
        console.log('Backend not connected, deleting from local state:', err);
      }

      // If backend fails, just update local state
      setProducts(products.filter(p => p._id !== productId));
      setSuccessMessage('Product deleted successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError('Error deleting product: ' + err.message);
    }
  };

  const handleSaveProduct = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const formData = new FormData(event.target);
      const productData = {
        name: formData.get('name'),
        price: parseFloat(formData.get('price')),
        stock: parseInt(formData.get('stock')),
        category: formData.get('category'),
        description: formData.get('description'),
        image: `https://source.unsplash.com/random/400x300/?${formData.get('name').toLowerCase()}`,
      };

      // Try backend first
      try {
        const url = editProduct 
          ? `http://localhost:5001/api/products/${editProduct._id}`
          : 'http://localhost:5001/api/products';
          
        const response = await fetch(url, {
          method: editProduct ? 'PUT' : 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify(productData)
        });

        if (response.ok) {
          const savedProduct = await response.json();
          if (editProduct) {
            setProducts(products.map(p => p._id === editProduct._id ? savedProduct : p));
          } else {
            setProducts([...products, savedProduct]);
          }
          setOpenDialog(false);
          setSuccessMessage(editProduct ? 'Product updated successfully' : 'Product added successfully');
          setTimeout(() => setSuccessMessage(''), 3000);
          return;
        }
      } catch (err) {
        console.log('Backend not connected, saving to local state:', err);
      }

      // If backend fails, just update local state
      const newProduct = {
        _id: editProduct ? editProduct._id : Date.now().toString(),
        ...productData
      };

      if (editProduct) {
        setProducts(products.map(p => p._id === editProduct._id ? newProduct : p));
      } else {
        setProducts([...products, newProduct]);
      }
      setOpenDialog(false);
      setSuccessMessage(editProduct ? 'Product updated successfully' : 'Product added successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError('Error saving product: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" gutterBottom>
          Product Management
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Products
                </Typography>
                <Typography variant="h4">
                  {products.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Low Stock Items
                </Typography>
                <Typography variant="h4">
                  {products.filter(p => p.stock < 50).length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Categories
                </Typography>
                <Typography variant="h4">
                  {categories.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Value
                </Typography>
                <Typography variant="h4">
                  ₹{products.reduce((sum, p) => sum + (p.price * p.stock), 0)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>

      <Paper sx={{ p: 2 }}>
        {successMessage && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {successMessage}
          </Alert>
        )}

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
          <TextField
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            sx={{ flexGrow: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            sx={{ width: 200 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <FilterList />
                </InputAdornment>
              ),
            }}
          >
            <MenuItem value="all">All Categories</MenuItem>
            {categories.map(category => (
              <MenuItem key={category} value={category}>
                {category}
              </MenuItem>
            ))}
          </TextField>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={handleAddProduct}
          >
            Add Product
          </Button>
        </Box>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
            <CircularProgress />
          </Box>
        ) : (
          <Grid container spacing={3}>
            {filteredProducts.map((product) => (
              <Grid item xs={12} sm={6} md={4} key={product._id}>
                <Card
                  component={motion.div}
                  whileHover={{ y: -4 }}
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <CardMedia
                    component="img"
                    height="200"
                    image={product.image}
                    alt={product.name}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Typography variant="h6" component="div">
                        {product.name}
                      </Typography>
                      <Box>
                        <IconButton
                          size="small"
                          onClick={() => handleEditProduct(product)}
                          sx={{ mr: 1 }}
                        >
                          <Edit />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => handleDeleteProduct(product._id)}
                        >
                          <Delete />
                        </IconButton>
                      </Box>
                    </Box>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {product.description}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="h6" color="primary">
                        ₹{product.price}
                      </Typography>
                      <Chip
                        label={`Stock: ${product.stock}`}
                        color={product.stock < 50 ? 'error' : 'success'}
                        size="small"
                      />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Paper>

      <Dialog
        open={openDialog}
        onClose={() => !loading && setOpenDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <form onSubmit={handleSaveProduct}>
          <DialogTitle>
            {editProduct ? 'Edit Product' : 'Add New Product'}
          </DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                name="name"
                label="Product Name"
                defaultValue={editProduct?.name}
                required
                fullWidth
                disabled={loading}
              />
              <TextField
                name="price"
                label="Price"
                type="number"
                defaultValue={editProduct?.price}
                required
                fullWidth
                disabled={loading}
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
              />
              <TextField
                name="stock"
                label="Stock"
                type="number"
                defaultValue={editProduct?.stock}
                required
                fullWidth
                disabled={loading}
              />
              <TextField
                name="category"
                label="Category"
                select
                defaultValue={editProduct?.category || categories[0]}
                required
                fullWidth
                disabled={loading}
              >
                {categories.map(category => (
                  <MenuItem key={category} value={category}>
                    {category}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                name="description"
                label="Description"
                multiline
                rows={3}
                defaultValue={editProduct?.description}
                required
                fullWidth
                disabled={loading}
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)} disabled={loading}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              variant="contained" 
              startIcon={loading ? <CircularProgress size={20} /> : <Save />}
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save Product'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </motion.div>
  );
};

export default ProductsTab;
