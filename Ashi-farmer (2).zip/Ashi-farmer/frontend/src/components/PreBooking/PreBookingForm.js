import React, { useState } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  InputAdornment
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { addDays } from 'date-fns';
import { addDays as addDaysFunc } from 'date-fns';

const PreBookingForm = ({ product, farmer, onSuccess }) => {
  const [formData, setFormData] = useState({
    quantity: '',
    unit: 'kg',
    deliveryDate: addDaysFunc(new Date(), 7),
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...formData,
          product: product._id,
          farmer: farmer._id,
          totalPrice: product.pricePerUnit * formData.quantity
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create pre-booking');
      }

      const data = await response.json();
      onSuccess(data);
      setFormData({
        quantity: '',
        unit: 'kg',
        deliveryDate: addDaysFunc(new Date(), 7),
        notes: ''
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const minDeliveryDate = addDaysFunc(new Date(), 7);
  const maxDeliveryDate = addDaysFunc(new Date(), 90);

  return (
    <Paper elevation={3} sx={{ p: 3, maxWidth: 500, mx: 'auto' }}>
      <Typography variant="h5" gutterBottom>
        Pre-book {product.name}
      </Typography>
      
      <form onSubmit={handleSubmit}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <TextField
              label="Quantity"
              type="number"
              required
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              InputProps={{
                inputProps: { min: 1 },
                endAdornment: (
                  <InputAdornment position="end">
                    {formData.unit}
                  </InputAdornment>
                )
              }}
              fullWidth
            />

            <FormControl sx={{ minWidth: 120 }}>
              <InputLabel>Unit</InputLabel>
              <Select
                value={formData.unit}
                label="Unit"
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
              >
                <MenuItem value="kg">Kg</MenuItem>
                <MenuItem value="dozen">Dozen</MenuItem>
                <MenuItem value="pieces">Pieces</MenuItem>
              </Select>
            </FormControl>
          </Box>

          <DatePicker
            label="Delivery Date"
            value={formData.deliveryDate}
            onChange={(newValue) => setFormData({ ...formData, deliveryDate: newValue })}
            minDate={minDeliveryDate}
            maxDate={maxDeliveryDate}
            slotProps={{
              textField: {
                fullWidth: true,
                required: true
              }
            }}
          />

          <TextField
            label="Notes"
            multiline
            rows={3}
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          />

          {error && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {error}
            </Alert>
          )}

          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography>
              Total Price: ₹{(product.pricePerUnit * formData.quantity || 0).toFixed(2)}
            </Typography>
            <Button
              type="submit"
              variant="contained"
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Pre-book Now'}
            </Button>
          </Box>
        </Box>
      </form>
    </Paper>
  );
};

export default PreBookingForm;
