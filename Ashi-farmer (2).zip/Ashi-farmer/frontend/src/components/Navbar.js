import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Badge,
  Box,
  Menu,
  MenuItem,
  useTheme,
  useMediaQuery,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material';
import {
  Menu as MenuIcon,
  ShoppingCart,
  Person,
  Favorite,
  Dashboard,
  Login,
  Logout,
  Info,
  ContactSupport,
  Home,
  Add,
  Store,
} from '@mui/icons-material';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';

const Navbar = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const [anchorEl, setAnchorEl] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  const menuItems = [
    { text: 'Home', icon: <Home />, path: '/' },
    // { text: 'Products', icon: <Store />, path: '/products' },
    { text: 'About', icon: <Info />, path: '/about' },
    { text: 'Contact', icon: <ContactSupport />, path: '/contact' },
    ...(user?.role === 'farmer' ? [{ text: 'Add Product', icon: <Add />, path: '/add-product' }] : []),
  ];

  const renderMobileMenu = () => (
    <Drawer
      anchor="right"
      open={mobileMenuOpen}
      onClose={() => setMobileMenuOpen(false)}
    >
      <Box sx={{ width: 250, pt: 2 }}>
        <List>
          {menuItems.map((item) => (
            <ListItem
              button
              key={item.text}
              component={Link}
              to={item.path}
              onClick={() => setMobileMenuOpen(false)}
              selected={location.pathname === item.path}
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
          {user && (
            <>
              <Divider />
              <ListItem button onClick={handleLogout}>
                <ListItemIcon>
                  <Logout />
                </ListItemIcon>
                <ListItemText primary="Logout" />
              </ListItem>
            </>
          )}
        </List>
      </Box>
    </Drawer>
  );

  return (
    <AppBar position="sticky" elevation={1} sx={{ backgroundColor: "#f0f0f0" }} >
      <Toolbar>
        <Typography
          variant="h6"
          component={Link}
          to="/"
          sx={{
            flexGrow: 1,
            textDecoration: 'none',
            color: 'blue',
            fontWeight: 'bold',
          }}
        >
          Farmer's Market
        </Typography>

        {isMobile ? (
          <>
            <IconButton
              color="blue"
              onClick={() => setMobileMenuOpen(true)}
              edge="end"
            >
              <MenuIcon />
            </IconButton>
            {renderMobileMenu()}
          </>
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Button
             style={{ color: "blue", fontWeight: 'bold'}}
              color="inherit"
              component={Link}
              to="/"
              startIcon={<Home />}
            >
              Home
            </Button>

            {/* <Button
            style={{ color: "blue", fontWeight: 'bold' }}
              color="inherit"
              component={Link}
              to="/products"
              startIcon={<Store />}
            >
              Products
            </Button> */}

            {user?.role === 'farmer' && (
              <Button
              style={{ color: "blue", fontWeight: 'bold' }}
                color="inherit"
                component={Link}
                to="/add-product"
                startIcon={<Add />}
              >
                Add Product
              </Button>
            )}

            <Button
            style={{ color: "blue", fontWeight: 'bold' }}
              color="inherit"
              component={Link}
              to="/about"
              startIcon={<Info />}
            >
              About
            </Button>

            <Button
            style={{ color: "blue", fontWeight: 'bold' }}
              color="inherit"
              component={Link}
              to="/contact"
              startIcon={<ContactSupport />}
            >
              Contact
            </Button>

            {user ? (
              <>
                {user.role === 'buyer' && (
                  <>
                    <IconButton
                      color="inherit"
                      component={Link}
                      to="/favorites"
                      size="large"
                    >
                      <Favorite />
                    </IconButton>
                    <IconButton
                      color="inherit"
                      component={Link}
                      to="/cart"
                      size="large"
                    >
                      <Badge
                        badgeContent={cartItems?.length || 0}
                        color="secondary"
                      >
                        <ShoppingCart />
                      </Badge>
                    </IconButton>
                  </>
                )}
                {user.role === 'farmer' && (
                  <Button
                  style={{ color: "blue", fontWeight: 'bold' }}
                    color="inherit"
                    component={Link}
                    to="/dashboard"
                    startIcon={<Dashboard />}
                  >
                    Dashboard
                  </Button>
                )}
                <IconButton
                  size="large"
                  onClick={handleMenu}
                  color="inherit"
                  sx={{ color: "blue" , fontWeight: 'bold'}}
                >
                  <Person />
                </IconButton>
                <Menu
                  anchorEl={anchorEl}
                  open={Boolean(anchorEl)}
                  onClose={handleClose}
                >
                  <MenuItem
                 
                    component={Link}
                    to="/profile"
                    onClick={handleClose}
                  >
                    Profile
                  </MenuItem>
                  <MenuItem onClick={handleLogout}>Logout</MenuItem>
                </Menu>
              </>
            ) : (
              <Button
                color="inherit"
                component={Link}
                to="/login"
                startIcon={<Login />}
              >
                Login
              </Button>
            )}
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
