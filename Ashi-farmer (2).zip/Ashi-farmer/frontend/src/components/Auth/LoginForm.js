import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  Alert,
  CircularProgress,
  ToggleButtonGroup,
  ToggleButton,
  Snackbar,
} from '@mui/material';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

const LoginForm = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [userType, setUserType] = useState('farmer'); // Default to farmer
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    // Clear error when user starts typing
    if (error) setError(null);
  };

  const handleUserTypeChange = (e, newValue) => {
    if (newValue !== null) {
      setUserType(newValue);
      // Clear error when user changes type
      if (error) setError(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Basic validation
      if (!formData.email || !formData.password) {
        throw new Error('Please fill in all fields');
      }

      if (!formData.email.includes('@')) {
        throw new Error('Please enter a valid email address');
      }

      const response = await fetch('http://localhost:5001/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          role: userType
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      // Log the received data for debugging
      console.log('Login response:', data);

      // Make sure we have all required user data
      if (!data.user || !data.user._id || !data.user.role) {
        throw new Error('Invalid user data received');
      }

      // Store token and user data
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));

      // Update auth context
      login(data.user, data.token);

      // Show success message
      setNotification({
        open: true,
        message: 'Login successful!',
        severity: 'success'
      });

      // Redirect based on role
      if (data.user.role === 'farmer') {
        navigate('/dashboard');
      } else {
        navigate('/');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError(err.message || 'Failed to login. Please try again.');
      setNotification({
        open: true,
        message: err.message || 'Failed to login. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  // For testing - remove in production
  const handleTestLogin = () => {
    setFormData({
      email: 'test@farmer.com',
      password: 'password123'
    });
    setUserType('farmer');
  };

  return (
    <Paper elevation={3} sx={{ p: 4, maxWidth: 400, mx: 'auto' }}>
      <Typography variant="h5" gutterBottom align="center">
        Login to Your Account
      </Typography>

      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
        <ToggleButtonGroup
          value={userType}
          exclusive
          onChange={handleUserTypeChange}
          fullWidth
          sx={{ mb: 3 }}
        >
          <ToggleButton 
            value="farmer"
            sx={{
              '&.Mui-selected': {
                backgroundColor: 'primary.main',
                color: 'white',
                '&:hover': {
                  backgroundColor: 'primary.dark',
                }
              }
            }}
          >
            Farmer
          </ToggleButton>
          <ToggleButton 
            value="buyer"
            sx={{
              '&.Mui-selected': {
                backgroundColor: 'primary.main',
                color: 'white',
                '&:hover': {
                  backgroundColor: 'primary.dark',
                }
              }
            }}
          >
            Buyer
          </ToggleButton>
        </ToggleButtonGroup>

        <TextField
          name="email"
          label="Email"
          type="email"
          fullWidth
          required
          value={formData.email}
          onChange={handleChange}
          margin="normal"
          error={!!error && error.includes('email')}
          helperText={error && error.includes('email') ? error : ''}
          disabled={loading}
        />

        <TextField
          name="password"
          label="Password"
          type="password"
          fullWidth
          required
          value={formData.password}
          onChange={handleChange}
          margin="normal"
          error={!!error && error.includes('password')}
          helperText={error && error.includes('password') ? error : ''}
          disabled={loading}
        />

        {error && !error.includes('email') && !error.includes('password') && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}

        <Button
          type="submit"
          variant="contained"
          fullWidth
          size="large"
          sx={{ 
            mt: 3,
            background: (theme) => 
              `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            '&:hover': {
              background: (theme) => 
                `linear-gradient(45deg, ${theme.palette.primary.dark}, ${theme.palette.primary.main})`,
            }
          }}
          disabled={loading}
        >
          {loading ? <CircularProgress size={24} color="inherit" /> : 'Login'}
        </Button>

        {/* For testing - remove in production */}
        <Button
          variant="outlined"
          fullWidth
          size="large"
          sx={{ mt: 2 }}
          onClick={handleTestLogin}
          disabled={loading}
        >
          Use Test Account
        </Button>

        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <Typography variant="body2">
            Don't have an account?{' '}
            <Link 
              to="/signup" 
              style={{ 
                textDecoration: 'none',
                color: 'primary.main',
                fontWeight: 'bold'
              }}
            >
              Sign up
            </Link>
          </Typography>
        </Box>
      </Box>
      <Snackbar
        open={notification.open}
        message={notification.message}
        severity={notification.severity}
        autoHideDuration={3000}
        onClose={() => setNotification({ open: false, message: '', severity: 'success' })}
      />
    </Paper>
  );
};

export default LoginForm;
