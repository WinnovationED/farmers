import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  MenuItem,
  CircularProgress,
  Box,
  Chip,
  IconButton
} from '@mui/material';
import { Edit, Delete, Add as AddIcon } from '@mui/icons-material';
import axios from 'axios';

const FarmerDashboard = () => {
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    quantity: '',
    unit: '',
    image: '',
    location: ''
  });

  useEffect(() => {
    fetchFarmerProducts();
  }, []);

  const fetchFarmerProducts = async () => {
    try {
      const farmerId = '64567890abcdef1234567890';
      const response = await axios.get(`http://localhost:5000/api/products?farmerId=${farmerId}`);
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
      setError('Failed to fetch products. Please try again.');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      category: '',
      quantity: '',
      unit: '',
      image: '',
      location: ''
    });
    setError('');
    setSuccess('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const requiredFields = ['name', 'description', 'price', 'category', 'quantity', 'unit', 'location'];
      const missingFields = requiredFields.filter(field => !formData[field]);
      
      if (missingFields.length > 0) {
        throw new Error(`Please fill in all required fields: ${missingFields.join(', ')}`);
      }

      const productData = {
        ...formData,
        farmerId: '64567890abcdef1234567890',
        price: Number(formData.price),
        quantity: Number(formData.quantity)
      };

      await axios.post('http://localhost:5000/api/products', productData);
      setSuccess('Product added successfully!');
      setOpen(false);
      resetForm();
      fetchFarmerProducts();
    } catch (error) {
      console.error('Error creating product:', error);
      setError(error.response?.data?.message || error.message || 'Failed to add product. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <Container sx={{ py: 4 }}>
      <Box sx={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        borderRadius: 2,
        p: 3,
        mb: 4
      }}>
        <Typography variant="h4" gutterBottom color="primary">
          Farmer Dashboard
        </Typography>
        <Typography variant="body1" color="text.secondary" paragraph>
          Manage your products and track your sales
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => setOpen(true)}
          sx={{ mb: 2 }}
        >
          Add New Product
        </Button>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
      </Box>

      <Grid container spacing={3}>
        {products.map((product) => (
          <Grid item key={product._id} xs={12} md={6}>
            <Card sx={{ 
              display: 'flex',
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              backdropFilter: 'blur(4px)'
            }}>
              <CardMedia
                component="img"
                sx={{ width: 140 }}
                image={product.image || 'https://via.placeholder.com/140x140?text=Product'}
                alt={product.name}
              />
              <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                <CardContent sx={{ flex: '1 0 auto' }}>
                  <Typography variant="h6">{product.name}</Typography>
                  <Typography variant="h6" color="primary" gutterBottom>
                    ₹{product.price}/{product.unit}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                    <Chip
                      label={`${product.quantity} ${product.unit} available`}
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                    <Chip
                      label={product.category}
                      size="small"
                      color="secondary"
                      variant="outlined"
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Location: {product.location}
                  </Typography>
                </CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', pl: 1, pb: 1 }}>
                  <IconButton aria-label="edit" color="primary">
                    <Edit />
                  </IconButton>
                  <IconButton aria-label="delete" color="error">
                    <Delete />
                  </IconButton>
                </Box>
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog 
        open={open} 
        onClose={() => {
          setOpen(false);
          resetForm();
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Add New Product</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          
          <TextField
            required
            fullWidth
            margin="normal"
            name="name"
            label="Product Name"
            value={formData.name}
            onChange={handleChange}
          />
          <TextField
            required
            fullWidth
            margin="normal"
            name="description"
            label="Description"
            multiline
            rows={4}
            value={formData.description}
            onChange={handleChange}
          />
          <TextField
            required
            fullWidth
            margin="normal"
            name="price"
            label="Price"
            type="number"
            value={formData.price}
            onChange={handleChange}
          />
          <TextField
            required
            fullWidth
            margin="normal"
            name="category"
            label="Category"
            select
            value={formData.category}
            onChange={handleChange}
          >
            <MenuItem value="vegetables">Vegetables</MenuItem>
            <MenuItem value="fruits">Fruits</MenuItem>
            <MenuItem value="grains">Grains</MenuItem>
          </TextField>
          <TextField
            required
            fullWidth
            margin="normal"
            name="quantity"
            label="Quantity"
            type="number"
            value={formData.quantity}
            onChange={handleChange}
          />
          <TextField
            required
            fullWidth
            margin="normal"
            name="unit"
            label="Unit"
            select
            value={formData.unit}
            onChange={handleChange}
          >
            <MenuItem value="kg">Kilogram (kg)</MenuItem>
            <MenuItem value="g">Gram (g)</MenuItem>
            <MenuItem value="piece">Piece</MenuItem>
            <MenuItem value="dozen">Dozen</MenuItem>
          </TextField>
          <TextField
            fullWidth
            margin="normal"
            name="image"
            label="Image URL (optional)"
            value={formData.image}
            onChange={handleChange}
          />
          <TextField
            required
            fullWidth
            margin="normal"
            name="location"
            label="Location"
            value={formData.location}
            onChange={handleChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setOpen(false);
            resetForm();
          }}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            color="primary"
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} /> : 'Add Product'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default FarmerDashboard;
