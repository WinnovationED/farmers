import React from 'react';
import {
  Box,
  Typography,
  Rating as MuiRating,
  Paper,
  Stack,
  Grid,
  Chip,
  ImageList,
  ImageListItem,
  Dialog,
  DialogContent
} from '@mui/material';
import { format } from 'date-fns';
import { useState } from 'react';

const RatingList = ({ ratings, stats }) => {
  const [selectedImage, setSelectedImage] = useState(null);

  return (
    <Box>
      {/* Rating Statistics */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={3} alignItems="center">
          <Grid item>
            <Typography variant="h4" component="div">
              {stats.averageRating.toFixed(1)}
            </Typography>
            <MuiRating
              value={stats.averageRating}
              precision={0.1}
              readOnly
            />
          </Grid>
          <Grid item>
            <Typography variant="body2" color="text.secondary">
              Based on {stats.totalRatings} ratings
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      {/* Individual Ratings */}
      <Stack spacing={2}>
        {ratings.map((rating) => (
          <Paper key={rating._id} sx={{ p: 3 }}>
            <Box sx={{ mb: 2 }}>
              <Stack direction="row" spacing={2} alignItems="center">
                <Typography variant="subtitle1">
                  {rating.rater.name}
                </Typography>
                <Chip
                  size="small"
                  label={rating.type === 'buyer-to-farmer' ? 'Buyer' : 'Farmer'}
                  color={rating.type === 'buyer-to-farmer' ? 'primary' : 'secondary'}
                />
                <Typography variant="caption" color="text.secondary">
                  {format(new Date(rating.createdAt), 'PPP')}
                </Typography>
              </Stack>
            </Box>

            <Box sx={{ mb: 2 }}>
              <MuiRating value={rating.rating} readOnly />
            </Box>

            <Typography variant="body1" paragraph>
              {rating.review}
            </Typography>

            {rating.deliveryPhotos && rating.deliveryPhotos.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Delivery Photos
                </Typography>
                <ImageList cols={3} gap={8}>
                  {rating.deliveryPhotos.map((photo, index) => (
                    <ImageListItem 
                      key={index}
                      sx={{ 
                        cursor: 'pointer',
                        '&:hover': { opacity: 0.8 }
                      }}
                      onClick={() => setSelectedImage(photo)}
                    >
                      <img
                        src={photo}
                        alt={`Delivery photo ${index + 1}`}
                        loading="lazy"
                        style={{
                          width: 100,
                          height: 100,
                          objectFit: 'cover',
                          borderRadius: 4
                        }}
                      />
                    </ImageListItem>
                  ))}
                </ImageList>
              </Box>
            )}
          </Paper>
        ))}
      </Stack>

      {/* Image Preview Dialog */}
      <Dialog
        open={Boolean(selectedImage)}
        onClose={() => setSelectedImage(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogContent sx={{ p: 0 }}>
          {selectedImage && (
            <img
              src={selectedImage}
              alt="Delivery photo"
              style={{
                width: '100%',
                height: 'auto',
                display: 'block'
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default RatingList;
