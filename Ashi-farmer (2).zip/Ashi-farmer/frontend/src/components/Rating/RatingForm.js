import React, { useState } from 'react';
import {
  Box,
  Typography,
  Rating as MuiRating,
  TextField,
  Button,
  Paper,
  IconButton,
  Stack,
  Alert,
  CircularProgress
} from '@mui/material';
import { PhotoCamera, Close } from '@mui/icons-material';

const RatingForm = ({ orderId, type, onSubmitSuccess, recipientName }) => {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [photos, setPhotos] = useState([]);
  const [photoFiles, setPhotoFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handlePhotoChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length + photos.length > 3) {
      setError('Maximum 3 photos allowed');
      return;
    }

    const newPhotos = files.map(file => ({
      file,
      preview: URL.createObjectURL(file)
    }));

    setPhotos([...photos, ...newPhotos]);
    setPhotoFiles([...photoFiles, ...files]);
  };

  const removePhoto = (index) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    const newPhotoFiles = photoFiles.filter((_, i) => i !== index);
    setPhotos(newPhotos);
    setPhotoFiles(newPhotoFiles);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) {
      setError('Please select a rating');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const formData = new FormData();
      formData.append('orderId', orderId);
      formData.append('rating', rating);
      formData.append('review', review);
      formData.append('type', type);

      photoFiles.forEach(file => {
        formData.append('photos', file);
      });

      const response = await fetch('http://localhost:5000/api/ratings', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to submit rating');
      }

      const data = await response.json();
      onSubmitSuccess(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Rate {recipientName}
      </Typography>
      
      <Box component="form" onSubmit={handleSubmit}>
        <Stack spacing={3}>
          <Box>
            <Typography component="legend">Rating</Typography>
            <MuiRating
              value={rating}
              onChange={(_, value) => setRating(value)}
              size="large"
            />
          </Box>

          <TextField
            label="Review"
            multiline
            rows={4}
            value={review}
            onChange={(e) => setReview(e.target.value)}
            required
            fullWidth
            placeholder="Share your experience..."
            inputProps={{ minLength: 10, maxLength: 500 }}
          />

          <Box>
            <input
              accept="image/*"
              type="file"
              id="photo-upload"
              multiple
              onChange={handlePhotoChange}
              style={{ display: 'none' }}
            />
            <label htmlFor="photo-upload">
              <Button
                variant="outlined"
                component="span"
                startIcon={<PhotoCamera />}
                disabled={photos.length >= 3}
              >
                Add Photos
              </Button>
            </label>
            
            <Typography variant="caption" sx={{ ml: 2 }}>
              {3 - photos.length} photos remaining
            </Typography>

            <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
              {photos.map((photo, index) => (
                <Box
                  key={index}
                  sx={{ position: 'relative' }}
                >
                  <img
                    src={photo.preview}
                    alt={`Preview ${index + 1}`}
                    style={{
                      width: 100,
                      height: 100,
                      objectFit: 'cover',
                      borderRadius: 4
                    }}
                  />
                  <IconButton
                    size="small"
                    onClick={() => removePhoto(index)}
                    sx={{
                      position: 'absolute',
                      top: -8,
                      right: -8,
                      bgcolor: 'background.paper'
                    }}
                  >
                    <Close />
                  </IconButton>
                </Box>
              ))}
            </Stack>
          </Box>

          {error && (
            <Alert severity="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            fullWidth
          >
            {loading ? <CircularProgress size={24} /> : 'Submit Rating'}
          </Button>
        </Stack>
      </Box>
    </Paper>
  );
};

export default RatingForm;
