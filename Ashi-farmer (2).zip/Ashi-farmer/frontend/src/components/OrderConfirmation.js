import React from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const OrderConfirmation = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const order = window.location.state?.order;

  if (!order) {
    return (
      <Box sx={{ mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          Order Confirmation
        </Typography>
        <Typography>
          Your order has been placed successfully!
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          mb: 4,
        }}
      >
        <CheckCircleIcon
          sx={{
            fontSize: isMobile ? 60 : 80,
            color: theme.palette.success.main,
          }}
        />
      </Box>

      <Typography
        variant="h4"
        align="center"
        sx={{
          color: theme.palette.success.main,
          mb: 2,
        }}
      >
        Order Placed Successfully!
      </Typography>

      <Card sx={{ p: 3, mb: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Order Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1">
                Order ID: {order._id}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1">
                Date: {new Date(order.createdAt).toLocaleDateString()}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Product: {order.product.name}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Quantity: {order.quantity}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Total Amount: ₹{order.totalAmount}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Status: {order.status}
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <Card sx={{ p: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Shipping Address
          </Typography>
          <Typography variant="body1">
            {order.shippingAddress.street}
          </Typography>
          <Typography variant="body1">
            {order.shippingAddress.city}, {order.shippingAddress.state}
          </Typography>
          <Typography variant="body1">
            {order.shippingAddress.zipCode}
          </Typography>
        </CardContent>
      </Card>

      <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate('/orders')}
          sx={{ mr: 2 }}
        >
          View Order
        </Button>
        <Button
          variant="outlined"
          onClick={() => navigate('/products')}
        >
          Continue Shopping
        </Button>
      </Box>
    </Box>
  );
};

export default OrderConfirmation;
