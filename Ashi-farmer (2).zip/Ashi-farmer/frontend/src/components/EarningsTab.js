import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Card,
  CardContent,
  Chip,
  IconButton,
  InputAdornment,
  MenuItem,
} from '@mui/material';
import {
  AccountBalance,
  CalendarToday,
  FilterList,
  GetApp,
  AccountBalanceWallet,
  Payment,
  Receipt,
} from '@mui/icons-material';
import { motion } from 'framer-motion';

const EarningsTab = () => {
  const [withdrawDialog, setWithdrawDialog] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const [dateFilter, setDateFilter] = useState('all');

  const bankAccounts = [
    { id: '1', name: 'SBI - XXXX4589' },
    { id: '2', name: 'HDFC - XXXX7823' },
  ];

  const transactions = [
    {
      id: '1',
      date: '2024-03-23',
      type: 'Order Payment',
      amount: 1250,
      status: 'completed',
      orderId: 'ORD001',
    },
    {
      id: '2',
      date: '2024-03-22',
      type: 'Withdrawal',
      amount: -5000,
      status: 'completed',
      reference: 'WTH001',
    },
    {
      id: '3',
      date: '2024-03-21',
      type: 'Order Payment',
      amount: 3450,
      status: 'completed',
      orderId: 'ORD002',
    },
  ];

  const stats = {
    totalEarnings: '₹45,850',
    availableBalance: '₹12,500',
    pendingPayouts: '₹3,200',
    totalOrders: '124',
  };

  const handleWithdraw = async () => {
    try {
      // Add your withdrawal API logic here
      setWithdrawDialog(false);
      // Show success message
    } catch (error) {
      // Show error message
    }
  };

  const StatCard = ({ title, value, icon: Icon, color }) => (
    <Card
      component={motion.div}
      whileHover={{ y: -4 }}
      sx={{
        height: '100%',
        background: `linear-gradient(45deg, ${color}22, ${color}11)`,
        border: `1px solid ${color}33`,
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Icon sx={{ color: color, mr: 1 }} />
          <Typography variant="h6" color="text.secondary">
            {title}
          </Typography>
        </Box>
        <Typography variant="h4" gutterBottom>
          {value}
        </Typography>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      {/* Stats Overview */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Earnings"
            value={stats.totalEarnings}
            icon={AccountBalance}
            color="#2196f3"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Available Balance"
            value={stats.availableBalance}
            icon={AccountBalanceWallet}
            color="#4caf50"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Pending Payouts"
            value={stats.pendingPayouts}
            icon={Payment}
            color="#ff9800"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Orders"
            value={stats.totalOrders}
            icon={Receipt}
            color="#9c27b0"
          />
        </Grid>
      </Grid>

      {/* Transaction History */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Typography variant="h6">Transaction History</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <TextField
            select
            size="small"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            sx={{ width: 150, mr: 2 }}
          >
            <MenuItem value="all">All Time</MenuItem>
            <MenuItem value="today">Today</MenuItem>
            <MenuItem value="week">This Week</MenuItem>
            <MenuItem value="month">This Month</MenuItem>
          </TextField>
          <Button
            variant="contained"
            startIcon={<GetApp />}
            sx={{ mr: 2 }}
          >
            Export
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={() => setWithdrawDialog(true)}
          >
            Withdraw Funds
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Reference</TableCell>
                <TableCell align="right">Amount</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                  <TableCell>{transaction.type}</TableCell>
                  <TableCell>
                    {transaction.orderId || transaction.reference}
                  </TableCell>
                  <TableCell align="right">
                    <Typography
                      color={transaction.amount > 0 ? 'success.main' : 'error.main'}
                    >
                      {transaction.amount > 0 ? '+' : ''}
                      ₹{Math.abs(transaction.amount)}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={transaction.status}
                      color={
                        transaction.status === 'completed'
                          ? 'success'
                          : transaction.status === 'pending'
                          ? 'warning'
                          : 'error'
                      }
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Withdraw Dialog */}
      <Dialog
        open={withdrawDialog}
        onClose={() => setWithdrawDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Withdraw Funds</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Alert severity="info" sx={{ mb: 2 }}>
              Available balance: {stats.availableBalance}
            </Alert>
            <TextField
              label="Amount"
              type="number"
              fullWidth
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">₹</InputAdornment>
                ),
              }}
            />
            <TextField
              select
              label="Select Bank Account"
              fullWidth
              value={selectedBank}
              onChange={(e) => setSelectedBank(e.target.value)}
            >
              {bankAccounts.map((account) => (
                <MenuItem key={account.id} value={account.id}>
                  {account.name}
                </MenuItem>
              ))}
            </TextField>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setWithdrawDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleWithdraw}
            disabled={!withdrawAmount || !selectedBank}
          >
            Withdraw
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default EarningsTab;
