import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Grid,
  Box,
  Avatar,
  Button,
  TextField,
  Divider,
  Card,
  CardContent,
  IconButton,
  Snackbar,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Autocomplete,
  Stack,
  CircularProgress
} from '@mui/material';
import {
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  PhotoCamera,
  LocationOn,
  Phone,
  Email,
  Work,
  School,
  Verified,
  Description,
  Agriculture
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import PreBookingForm from './PreBookingForm'; // Import the PreBookingForm component

const FarmerProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [editing, setEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState({});
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [imageUploadDialog, setImageUploadDialog] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:5001/api/farmer/profile', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }

      const data = await response.json();
      setProfile(data);
      setEditedProfile(data);
    } catch (error) {
      setSnackbar({
        open: true,
        message: 'Failed to load profile',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setEditing(true);
    setEditedProfile({ ...profile });
  };

  const handleCancel = () => {
    setEditing(false);
    setEditedProfile(profile);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedProfile((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      
      // Format the profile data to match the backend schema
      const profileData = {
        farmName: editedProfile.farmName,
        farmSize: editedProfile.farmSize,
        farmLocation: editedProfile.farmLocation,
        cropTypes: editedProfile.cropTypes || [],
        experienceYears: editedProfile.experienceYears || 0,
        certification: editedProfile.certification || 'None',
        bio: editedProfile.bio || ''
      };

      const response = await fetch('http://localhost:5001/api/farmer/profile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(profileData),
      });

      // Check if response is JSON before parsing
      const contentType = response.headers.get('content-type');
      if (!response.ok) {
        if (contentType && contentType.indexOf('application/json') !== -1) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to update profile');
        } else {
          throw new Error('Server error: ' + response.status);
        }
      }

      const updatedProfile = await response.json();
      setProfile(updatedProfile);
      setEditedProfile(updatedProfile);
      setEditing(false);
      setSnackbar({
        open: true,
        message: 'Profile updated successfully',
        severity: 'success',
      });
    } catch (error) {
      console.error('Profile update error:', error);
      setSnackbar({
        open: true,
        message: error.message || 'Failed to update profile',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setSnackbar({
          open: true,
          message: 'Image size should be less than 5MB',
          severity: 'error'
        });
        return;
      }

      if (!['image/jpeg', 'image/jpg', 'image/png'].includes(file.type)) {
        setSnackbar({
          open: true,
          message: 'Only JPEG, JPG and PNG files are allowed',
          severity: 'error'
        });
        return;
      }

      setSelectedImage(file);
    }
  };

  const handleImageUpload = async () => {
    if (!selectedImage) return;

    const formData = new FormData();
    formData.append('profileImage', selectedImage);

    try {
      setLoading(true);
      const response = await fetch('http://localhost:5001/api/farmer/profile', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to upload image');
      }

      const data = await response.json();
      setProfile((prev) => ({ ...prev, profileImage: data.imageUrl }));
      setEditedProfile((prev) => ({ ...prev, profileImage: data.imageUrl }));
      setImageUploadDialog(false);
      setSnackbar({
        open: true,
        message: 'Profile image updated successfully',
        severity: 'success',
      });
    } catch (error) {
      console.error('Image upload error:', error);
      setSnackbar({
        open: true,
        message: 'Failed to upload image',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Grid container spacing={4}>
          {/* Profile Header */}
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <Box sx={{ position: 'relative' }}>
                <Avatar
                  src={profile?.profileImage || 'https://via.placeholder.com/150'}
                  sx={{
                    width: 120,
                    height: 120,
                    border: '4px solid',
                    borderColor: 'primary.main',
                  }}
                />
                <IconButton
                  sx={{
                    position: 'absolute',
                    bottom: 0,
                    right: 0,
                    bgcolor: 'primary.main',
                    '&:hover': { bgcolor: 'primary.dark' },
                  }}
                  onClick={() => setImageUploadDialog(true)}
                >
                  <PhotoCamera sx={{ color: 'white' }} />
                </IconButton>
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography variant="h4" gutterBottom>
                  {profile?.farmName || 'Your Farm'}
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, color: 'text.secondary' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <LocationOn fontSize="small" />
                    <Typography variant="body2">
                      {profile?.farmLocation || 'Add your farm location'}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <School fontSize="small" />
                    <Typography variant="body2">
                      {profile?.experienceYears || 0} years experience
                    </Typography>
                  </Box>
                </Box>
              </Box>
              <Box>
                {editing ? (
                  <Stack direction="row" spacing={1}>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<SaveIcon />}
                      onClick={handleSave}
                      disabled={loading}
                    >
                      Save
                    </Button>
                    <Button
                      variant="outlined"
                      color="error"
                      startIcon={<CancelIcon />}
                      onClick={handleCancel}
                      disabled={loading}
                    >
                      Cancel
                    </Button>
                  </Stack>
                ) : (
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<EditIcon />}
                    onClick={handleEdit}
                    disabled={loading}
                  >
                    Edit Profile
                  </Button>
                )}
              </Box>
            </Box>
          </Grid>

          {/* Profile Sections */}
          <Grid item xs={12}>
            <Divider sx={{ my: 3 }} />
          </Grid>

          {/* Farm Information */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Agriculture fontSize="small" sx={{ mr: 1 }} />
                  Farm Information
                </Typography>
                {editing ? (
                  <>
                    <TextField
                      fullWidth
                      label="Farm Name"
                      name="farmName"
                      value={editedProfile.farmName || ''}
                      onChange={handleChange}
                      margin="normal"
                      required
                    />
                    <TextField
                      fullWidth
                      label="Farm Size (acres)"
                      name="farmSize"
                      type="number"
                      value={editedProfile.farmSize || ''}
                      onChange={handleChange}
                      margin="normal"
                      required
                    />
                    <TextField
                      fullWidth
                      label="Farm Location"
                      name="farmLocation"
                      value={editedProfile.farmLocation || ''}
                      onChange={handleChange}
                      margin="normal"
                      required
                    />
                  </>
                ) : (
                  <>
                    <Typography variant="body1">
                      <strong>Farm Name:</strong> {profile?.farmName}
                    </Typography>
                    <Typography variant="body1">
                      <strong>Farm Size:</strong> {profile?.farmSize} acres
                    </Typography>
                    <Typography variant="body1">
                      <strong>Location:</strong> {profile?.farmLocation}
                    </Typography>
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>

          {/* Crop Types */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Work fontSize="small" sx={{ mr: 1 }} />
                  Crops & Certifications
                </Typography>
                {editing ? (
                  <>
                    <FormControl fullWidth margin="normal">
                      <InputLabel>Crop Types</InputLabel>
                      <Select
                        multiple
                        name="cropTypes"
                        value={editedProfile.cropTypes || []}
                        onChange={handleChange}
                        renderValue={(selected) => (
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {selected.map((value) => (
                              <Chip key={value} label={value} />
                            ))}
                          </Box>
                        )}
                      >
                        <MenuItem value="Vegetables">Vegetables</MenuItem>
                        <MenuItem value="Fruits">Fruits</MenuItem>
                        <MenuItem value="Grains">Grains</MenuItem>
                        <MenuItem value="Dairy">Dairy</MenuItem>
                        <MenuItem value="Poultry">Poultry</MenuItem>
                        <MenuItem value="Meat">Meat</MenuItem>
                        <MenuItem value="Organic">Organic</MenuItem>
                        <MenuItem value="Others">Others</MenuItem>
                      </Select>
                    </FormControl>
                    <FormControl fullWidth margin="normal">
                      <InputLabel>Certification</InputLabel>
                      <Select
                        name="certification"
                        value={editedProfile.certification || ''}
                        onChange={handleChange}
                      >
                        <MenuItem value="Organic">Organic</MenuItem>
                        <MenuItem value="Conventional">Conventional</MenuItem>
                        <MenuItem value="None">None</MenuItem>
                      </Select>
                    </FormControl>
                  </>
                ) : (
                  <>
                    <Typography variant="body1">
                      <strong>Crop Types:</strong>
                      {profile?.cropTypes?.join(', ') || 'Not specified'}
                    </Typography>
                    <Typography variant="body1">
                      <strong>Certification:</strong>
                      {profile?.certification || 'Not specified'}
                    </Typography>
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>

          {/* Experience & Bio */}
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Description fontSize="small" sx={{ mr: 1 }} />
                  Experience & Bio
                </Typography>
                {editing ? (
                  <>
                    <TextField
                      fullWidth
                      label="Years of Experience"
                      name="experienceYears"
                      type="number"
                      value={editedProfile.experienceYears || ''}
                      onChange={handleChange}
                      margin="normal"
                    />
                    <TextField
                      fullWidth
                      label="Bio"
                      name="bio"
                      multiline
                      rows={4}
                      value={editedProfile.bio || ''}
                      onChange={handleChange}
                      margin="normal"
                      placeholder="Tell us about your farming journey..."
                    />
                  </>
                ) : (
                  <>
                    <Typography variant="body1">
                      <strong>Experience:</strong> {profile?.experienceYears} years
                    </Typography>
                    {profile?.bio && (
                      <Typography variant="body1" sx={{ mt: 2 }}>
                        <strong>Bio:</strong>
                        <Box component="div" sx={{ mt: 1 }}>
                          {profile.bio}
                        </Box>
                      </Typography>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>

          {/* Pre-Booking Form */}
          <Grid item xs={12}>
            <Paper sx={{ p: 3, mb: 2, bgcolor: 'background.paper' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Agriculture fontSize="large" sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6" gutterBottom>
                  Pre-Book Crops
                </Typography>
              </Box>
              <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 3 }}>
                Place pre-orders for upcoming harvests
              </Typography>
              {profile && (
                <PreBookingForm farmer={profile} />
              )}
            </Paper>
          </Grid>
        </Grid>
      </Paper>

      {/* Image Upload Dialog */}
      <Dialog open={imageUploadDialog} onClose={() => setImageUploadDialog(false)}>
        <DialogTitle>Upload Profile Image</DialogTitle>
        <DialogContent>
          <input
            accept="image/*"
            style={{ display: 'none' }}
            id="image-upload"
            type="file"
            onChange={handleImageChange}
          />
          <label htmlFor="image-upload">
            <Button
              variant="contained"
              component="span"
              fullWidth
              startIcon={<PhotoCamera />}
              sx={{ mb: 2 }}
            >
              Choose Image
            </Button>
          </label>
          {selectedImage && (
            <Box sx={{ textAlign: 'center' }}>
              <img
                src={URL.createObjectURL(selectedImage)}
                alt="Preview"
                style={{
                  maxWidth: '100%',
                  maxHeight: 200,
                  objectFit: 'contain',
                  border: '1px solid #ccc',
                  borderRadius: 4,
                }}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setImageUploadDialog(false)}>Cancel</Button>
          <Button onClick={handleImageUpload} variant="contained" color="primary">
            Upload
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default FarmerProfile;
