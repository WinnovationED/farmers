import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Menu,
  MenuItem,
  TextField,
  InputAdornment,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import {
  MoreVert,
  Search,
  FilterList,
  LocalShipping,
  Payment,
  Inventory,
  Person,
} from '@mui/icons-material';
import { motion } from 'framer-motion';

const OrdersTab = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [orderDetailsOpen, setOrderDetailsOpen] = useState(false);

  // Sample data - replace with actual data from your backend
  const orders = [
    {
      id: 'ORD001',
      customer: 'John Doe',
      products: ['Tomatoes', 'Potatoes'],
      total: '₹1,250',
      status: 'processing',
      date: '2024-03-23',
      address: '123 Main St, City',
      payment: 'Paid',
    },
    {
      id: 'ORD002',
      customer: 'Jane Smith',
      products: ['Onions', 'Carrots'],
      total: '₹850',
      status: 'delivered',
      date: '2024-03-22',
      address: '456 Oak St, Town',
      payment: 'Paid',
    },
    {
      id: 'ORD003',
      customer: 'Mike Johnson',
      products: ['Apples', 'Oranges'],
      total: '₹2,100',
      status: 'pending',
      date: '2024-03-21',
      address: '789 Pine St, Village',
      payment: 'Pending',
    },
  ];

  const handleActionClick = (event, order) => {
    setAnchorEl(event.currentTarget);
    setSelectedOrder(order);
  };

  const handleActionClose = () => {
    setAnchorEl(null);
    setSelectedOrder(null);
  };

  const handleFilterClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleStatusFilter = (status) => {
    setStatusFilter(status);
    handleFilterClose();
  };

  const handleViewDetails = () => {
    setOrderDetailsOpen(true);
    handleActionClose();
  };

  const handleCloseDetails = () => {
    setOrderDetailsOpen(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'processing':
        return 'warning';
      case 'delivered':
        return 'success';
      case 'cancelled':
        return 'error';
      case 'pending':
        return 'info';
      default:
        return 'default';
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch = order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const OrderDetailsDialog = () => (
    <Dialog
      open={orderDetailsOpen}
      onClose={handleCloseDetails}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        Order Details - {selectedOrder?.id}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Person sx={{ mr: 1 }} />
                  <Typography variant="h6">Customer Information</Typography>
                </Box>
                <Typography><strong>Name:</strong> {selectedOrder?.customer}</Typography>
                <Typography><strong>Address:</strong> {selectedOrder?.address}</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Payment sx={{ mr: 1 }} />
                  <Typography variant="h6">Payment Details</Typography>
                </Box>
                <Typography><strong>Total Amount:</strong> {selectedOrder?.total}</Typography>
                <Typography><strong>Status:</strong> {selectedOrder?.payment}</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Inventory sx={{ mr: 1 }} />
                  <Typography variant="h6">Products</Typography>
                </Box>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Item</TableCell>
                      <TableCell align="right">Quantity</TableCell>
                      <TableCell align="right">Price</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedOrder?.products.map((product) => (
                      <TableRow key={product}>
                        <TableCell>{product}</TableCell>
                        <TableCell align="right">1</TableCell>
                        <TableCell align="right">₹500</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleCloseDetails}>Close</Button>
        <Button variant="contained" color="primary" startIcon={<LocalShipping />}>
          Update Status
        </Button>
      </DialogActions>
    </Dialog>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" gutterBottom>
          Orders Management
        </Typography>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Orders
                </Typography>
                <Typography variant="h4">
                  {orders.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Pending Orders
                </Typography>
                <Typography variant="h4">
                  {orders.filter(order => order.status === 'pending').length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Processing Orders
                </Typography>
                <Typography variant="h4">
                  {orders.filter(order => order.status === 'processing').length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Delivered Orders
                </Typography>
                <Typography variant="h4">
                  {orders.filter(order => order.status === 'delivered').length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>

      <Paper sx={{ p: 2 }}>
        <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
          <TextField
            placeholder="Search orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            sx={{ flexGrow: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <Button
            variant="outlined"
            startIcon={<FilterList />}
            onClick={handleFilterClick}
          >
            Filter
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Order ID</TableCell>
                <TableCell>Customer</TableCell>
                <TableCell>Products</TableCell>
                <TableCell>Total</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Date</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id} hover>
                  <TableCell>{order.id}</TableCell>
                  <TableCell>{order.customer}</TableCell>
                  <TableCell>{order.products.join(', ')}</TableCell>
                  <TableCell>{order.total}</TableCell>
                  <TableCell>
                    <Chip
                      label={order.status}
                      color={getStatusColor(order.status)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>{new Date(order.date).toLocaleDateString()}</TableCell>
                  <TableCell align="right">
                    <IconButton onClick={(e) => handleActionClick(e, order)}>
                      <MoreVert />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Action Menu */}
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleActionClose}
        >
          <MenuItem onClick={handleViewDetails}>View Details</MenuItem>
          <MenuItem onClick={handleActionClose}>Update Status</MenuItem>
          <MenuItem onClick={handleActionClose}>Print Invoice</MenuItem>
        </Menu>

        {/* Filter Menu */}
        <Menu
          anchorEl={filterAnchorEl}
          open={Boolean(filterAnchorEl)}
          onClose={handleFilterClose}
        >
          <MenuItem onClick={() => handleStatusFilter('all')}>All Orders</MenuItem>
          <MenuItem onClick={() => handleStatusFilter('pending')}>Pending</MenuItem>
          <MenuItem onClick={() => handleStatusFilter('processing')}>Processing</MenuItem>
          <MenuItem onClick={() => handleStatusFilter('delivered')}>Delivered</MenuItem>
          <MenuItem onClick={() => handleStatusFilter('cancelled')}>Cancelled</MenuItem>
        </Menu>

        {/* Order Details Dialog */}
        {selectedOrder && <OrderDetailsDialog />}
      </Paper>
    </motion.div>
  );
};

export default OrdersTab;
