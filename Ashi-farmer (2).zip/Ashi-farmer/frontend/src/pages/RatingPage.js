import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Tabs,
  Tab,
  Alert,
  CircularProgress
} from '@mui/material';
import RatingForm from '../components/Rating/RatingForm';
import RatingList from '../components/Rating/RatingList';

const RatingPage = () => {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    fetchOrderAndRatings();
  }, [orderId]);

  const fetchOrderAndRatings = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch order details
      const orderResponse = await fetch(`http://localhost:5000/api/orders/${orderId}`);
      if (!orderResponse.ok) {
        throw new Error('Failed to fetch order details');
      }
      const orderData = await orderResponse.json();
      setOrder(orderData);

      // Fetch ratings for this order
      const ratingsResponse = await fetch(`http://localhost:5000/api/ratings/order/${orderId}`);
      if (!ratingsResponse.ok) {
        throw new Error('Failed to fetch ratings');
      }
      const ratingsData = await ratingsResponse.json();
      setRatings(ratingsData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRatingSubmit = (newRating) => {
    setRatings([...ratings, newRating]);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  if (!order) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="info">Order not found</Alert>
      </Container>
    );
  }

  const canRateAsBuyer = order.buyer._id === localStorage.getItem('userId') && 
    !ratings.some(r => r.type === 'buyer-to-farmer');

  const canRateAsFarmer = order.farmer._id === localStorage.getItem('userId') && 
    !ratings.some(r => r.type === 'farmer-to-buyer');

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Order Ratings & Reviews
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={(_, newValue) => setActiveTab(newValue)}>
          <Tab label="View Ratings" />
          {(canRateAsBuyer || canRateAsFarmer) && <Tab label="Submit Rating" />}
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <Box>
          {ratings.length > 0 ? (
            <RatingList 
              ratings={ratings}
              stats={{
                averageRating: ratings.reduce((acc, r) => acc + r.rating, 0) / ratings.length,
                totalRatings: ratings.length
              }}
            />
          ) : (
            <Alert severity="info">No ratings yet for this order</Alert>
          )}
        </Box>
      )}

      {activeTab === 1 && (canRateAsBuyer || canRateAsFarmer) && (
        <RatingForm
          orderId={orderId}
          type={canRateAsBuyer ? 'buyer-to-farmer' : 'farmer-to-buyer'}
          recipientName={canRateAsBuyer ? order.farmer.name : order.buyer.name}
          onSubmitSuccess={handleRatingSubmit}
        />
      )}
    </Container>
  );
};

export default RatingPage;
