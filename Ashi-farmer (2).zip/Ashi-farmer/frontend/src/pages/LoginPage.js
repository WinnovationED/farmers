import React from 'react';
import { Container, Box, Typography } from '@mui/material';
import LoginForm from '../components/Auth/LoginForm';

const LoginPage = () => {
  return (
    <Container maxWidth="sm">
      <Box sx={{ py: 8 }}>
        <Typography variant="h4" align="center" gutterBottom>
          Welcome Back
        </Typography>
        <Typography variant="body1" align="center" color="text.secondary" sx={{ mb: 4 }}>
          Login to access your account
        </Typography>
        <LoginForm />
      </Box>
    </Container>
  );
};

export default LoginPage;
