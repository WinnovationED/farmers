import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import AddProductForm from '../components/AddProductForm';
import { useNavigate } from 'react-router-dom';

const AddProductPage = () => {
  const navigate = useNavigate();

  const handleProductAdded = () => {
    // Show success message and redirect to product list
    setTimeout(() => {
      // Navigate to home page which will trigger a fresh product fetch
      navigate('/', { state: { refresh: true } });
    }, 1500);
  };

  return (
    <Container>
      <Box sx={{ py: 4 }}>
        <Typography variant="h4" gutterBottom align="center">
          Add New Product
        </Typography>
        <AddProductForm onProductAdded={handleProductAdded} />
      </Box>
    </Container>
  );
};

export default AddProductPage;
