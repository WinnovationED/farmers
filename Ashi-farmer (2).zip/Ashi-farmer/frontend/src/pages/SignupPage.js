import React from 'react';
import { Container, Box, Typography } from '@mui/material';
import SignupForm from '../components/Auth/SignupForm';

const SignupPage = () => {
  return (
    <Container maxWidth="md">
      <Box sx={{ py: 8 }}>
        <Typography variant="h4" align="center" gutterBottom>
          Create Your Account
        </Typography>
        <Typography variant="body1" align="center" color="text.secondary" sx={{ mb: 4 }}>
          Join our marketplace as a buyer or farmer
        </Typography>
        <SignupForm />
      </Box>
    </Container>
  );
};

export default SignupPage;
