import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Button,
  Grid,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Snackbar,
  Alert,
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const PreOrders = () => {
  const { user } = useAuth();
  const [preOrders, setPreOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  useEffect(() => {
    fetchPreOrders();
  }, [statusFilter]);

  const fetchPreOrders = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:5001/api/pre-orders/${user.role === 'farmer' ? 'farmer' : 'buyer'}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        }
      );

      setPreOrders(response.data);
    } catch (error) {
      console.error('Error fetching pre-orders:', error);
      setSnackbar({
        open: true,
        message: 'Failed to fetch pre-orders',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (preOrderId, newStatus) => {
    try {
      await axios.patch(
        `http://localhost:5001/api/pre-orders/${preOrderId}/status`,
        { status: newStatus },
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        }
      );

      setSnackbar({
        open: true,
        message: 'Pre-order status updated successfully',
        severity: 'success',
      });

      fetchPreOrders();
    } catch (error) {
      console.error('Error updating pre-order status:', error);
      setSnackbar({
        open: true,
        message: 'Failed to update pre-order status',
        severity: 'error',
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const filteredPreOrders = preOrders.filter(preOrder => {
    if (statusFilter === 'all') return true;
    return preOrder.status === statusFilter;
  });

  return (
    <Box sx={{ mt: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12}>
            <Typography variant="h5" gutterBottom>
              {user.role === 'farmer' ? 'My Pre-Orders' : 'My Pre-Bookings'}
            </Typography>
          </Grid>
          {user.role === 'farmer' && (
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  label="Status"
                >
                  <MenuItem value="all">All Statuses</MenuItem>
                  <MenuItem value="pending">Pending</MenuItem>
                  <MenuItem value="confirmed">Confirmed</MenuItem>
                  <MenuItem value="rejected">Rejected</MenuItem>
                  <MenuItem value="completed">Completed</MenuItem>
                  <MenuItem value="cancelled">Cancelled</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}
        </Grid>

        <TableContainer component={Paper} sx={{ mt: 2 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Crop</TableCell>
                <TableCell>Quantity</TableCell>
                <TableCell>Expected Harvest Date</TableCell>
                <TableCell>Price (₹)</TableCell>
                <TableCell>Status</TableCell>
                {user.role === 'farmer' && <TableCell>Action</TableCell>}
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredPreOrders.map((preOrder) => (
                <TableRow key={preOrder._id}>
                  <TableCell>
                    {preOrder.crop} - {preOrder.variety}
                  </TableCell>
                  <TableCell>
                    {preOrder.quantity} {preOrder.unit}
                  </TableCell>
                  <TableCell>
                    {new Date(preOrder.expectedHarvestDate).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {preOrder.totalPrice.toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outlined"
                      color={getStatusColor(preOrder.status)}
                      size="small"
                    >
                      {preOrder.status}
                    </Button>
                  </TableCell>
                  {user.role === 'farmer' && (
                    <TableCell>
                      {preOrder.status === 'pending' && (
                        <>
                          <Button
                            variant="contained"
                            color="success"
                            size="small"
                            onClick={() => handleStatusChange(preOrder._id, 'confirmed')}
                          >
                            Confirm
                          </Button>
                          <Button
                            variant="contained"
                            color="error"
                            size="small"
                            sx={{ ml: 1 }}
                            onClick={() => handleStatusChange(preOrder._id, 'rejected')}
                          >
                            Reject
                          </Button>
                        </>
                      )}
                      {preOrder.status === 'confirmed' && (
                        <>
                          <Button
                            variant="contained"
                            color="success"
                            size="small"
                            onClick={() => handleStatusChange(preOrder._id, 'completed')}
                          >
                            Complete
                          </Button>
                          <Button
                            variant="contained"
                            color="error"
                            size="small"
                            sx={{ ml: 1 }}
                            onClick={() => handleStatusChange(preOrder._id, 'cancelled')}
                          >
                            Cancel
                          </Button>
                        </>
                      )}
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {loading && (
          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Typography>Loading pre-orders...</Typography>
          </Box>
        )}

        {!loading && filteredPreOrders.length === 0 && (
          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Typography>No pre-orders found</Typography>
          </Box>
        )}
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

const getStatusColor = (status) => {
  switch (status) {
    case 'pending':
      return 'warning';
    case 'confirmed':
      return 'success';
    case 'rejected':
      return 'error';
    case 'completed':
      return 'success';
    case 'cancelled':
      return 'error';
    default:
      return 'default';
  }
};

export default PreOrders;
