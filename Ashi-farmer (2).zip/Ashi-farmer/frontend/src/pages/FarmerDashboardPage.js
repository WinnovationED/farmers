import React from 'react';
import { Container, Paper, Tabs, Tab, Box } from '@mui/material';
import FarmerOrdersDashboard from '../components/Dashboard/FarmerOrdersDashboard';

const FarmerDashboardPage = () => {
  const [tabValue, setTabValue] = React.useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          centered
        >
          <Tab label="Orders" />
          <Tab label="Products" />
          <Tab label="Analytics" />
        </Tabs>
      </Paper>

      <TabPanel value={tabValue} index={0}>
        <FarmerOrdersDashboard />
      </TabPanel>
      <TabPanel value={tabValue} index={1}>
        {/* Add your Products management component here */}
      </TabPanel>
      <TabPanel value={tabValue} index={2}>
        {/* Add your Analytics component here */}
      </TabPanel>
    </Container>
  );
};

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <Box>{children}</Box>}
    </div>
  );
};

export default FarmerDashboardPage;
