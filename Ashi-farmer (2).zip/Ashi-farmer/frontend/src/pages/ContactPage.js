import React, { useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  TextField,
  Button,
  Card,
  CardContent,
  useTheme,
  useMediaQuery,
  Paper,
  Snackbar,
  Alert,
  Fade,
} from '@mui/material';
import {
  Phone,
  Email,
  LocationOn,
  WhatsApp,
  Send,
} from '@mui/icons-material';

const ContactPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  const contactInfo = [
    {
      icon: <Phone fontSize="large" color="primary" />,
      title: 'Phone',
      content: '+91 954168611',
      link: 'tel:+911234567890',
    },
    {
      icon: <Email fontSize="large" color="primary" />,
      title: 'Email',
      content: 'rashid@gmail.com',
      link: 'mailto:support@farmertable.com',
    },
    {
      icon: <WhatsApp fontSize="large" color="primary" />,
      title: 'WhatsApp',
      content: '+91 987-654-3210',
      link: 'https://wa.me/919876543210',
    },
    {
      icon: <LocationOn fontSize="large" color="primary" />,
      title: 'Address',
      content: '123 Farmer Street, Agri Tower, Tech City - 400001',
      link: 'https://maps.google.com/?q=123+Farmer+Street',
    },
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5001/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      setSnackbar({
        open: true,
        message: 'Thank you for your message! We will get back to you soon.',
        severity: 'success',
      });

      // Clear form
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: '',
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: error.message || 'Failed to send message. Please try again.',
        severity: 'error',
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      {/* Hero Section */}
      <Box sx={{ textAlign: 'center', mb: 8 }}>
        <Fade in timeout={1000}>
          <Typography
            variant="h2"
            gutterBottom
            sx={{
              fontWeight: 'bold',
              background: 'linear-gradient(45deg, #2196F3 30%, #4CAF50 90%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Get in Touch
          </Typography>
        </Fade>
        <Fade in timeout={1500}>
          <Typography variant="h5" color="text.secondary">
            We're here to help and answer any questions you might have
          </Typography>
        </Fade>
      </Box>

      <Grid container spacing={4}>
        {/* Contact Information */}
        <Grid item xs={12} md={5}>
          <Fade in timeout={2000}>
            <Paper elevation={3} sx={{ p: 4, height: '100%', borderRadius: 4 }}>
              <Typography variant="h4" gutterBottom>
                Contact Details
              </Typography>
              <Typography variant="body1" color="text.secondary" paragraph>
                Have questions? We're here to help! Reach out to us through any of these channels:
              </Typography>
              
              <Box sx={{ mt: 4 }}>
                {contactInfo.map((info, index) => (
                  <Fade in timeout={2200 + (index * 200)} key={info.title}>
                    <Box
                      component="a"
                      href={info.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        mb: 3,
                        textDecoration: 'none',
                        color: 'inherit',
                        transition: 'transform 0.3s ease',
                        '&:hover': {
                          transform: 'translateX(8px)',
                        },
                      }}
                    >
                      <Box sx={{ mr: 2 }}>{info.icon}</Box>
                      <Box>
                        <Typography variant="h6" gutterBottom>
                          {info.title}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {info.content}
                        </Typography>
                      </Box>
                    </Box>
                  </Fade>
                ))}
              </Box>
            </Paper>
          </Fade>
        </Grid>

        {/* Contact Form */}
        <Grid item xs={12} md={7}>
          <Fade in timeout={2000}>
            <Paper
              elevation={3}
              component="form"
              onSubmit={handleSubmit}
              sx={{ p: 4, borderRadius: 4 }}
            >
              <Typography variant="h4" gutterBottom>
                Send us a Message
              </Typography>
              <Typography variant="body1" color="text.secondary" paragraph>
                Fill out the form below and we'll get back to you as soon as possible.
              </Typography>

              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    multiline
                    rows={4}
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12}>
                  <Button
                    type="submit"
                    // variant="contained"
                    size="large"
                    endIcon={<Send />}
                    sx={{
                      py: 1.5,
                      px: 4,
                      
                      transition: 'transform 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-4px)',
                      },
                    }}
                  >
                    Send Message
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Fade>
        </Grid>
      </Grid>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ContactPage;
