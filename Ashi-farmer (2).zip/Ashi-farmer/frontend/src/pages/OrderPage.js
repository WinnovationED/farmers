import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Stepper,
  Step,
  StepLabel,
  Grid,
  Box,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import axios from '../utils/axios';

const steps = ['Shipping Details', 'Order Review', 'Payment'];

const OrderPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { product, quantity = 1 } = location.state || {};

  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [shippingDetails, setShippingDetails] = useState({
    street: '',
    city: '',
    state: '',
    zipCode: '',
    phone: ''
  });

  // Redirect if no product
  if (!product) {
    navigate('/products');
    return null;
  }

  const handleShippingDetailsChange = (e) => {
    setShippingDetails({
      ...shippingDetails,
      [e.target.name]: e.target.value
    });
  };

  const isShippingDetailsValid = () => {
    return Object.values(shippingDetails).every(value => value.trim() !== '');
  };

  const handleNext = () => {
    if (activeStep === 0 && !isShippingDetailsValid()) {
      setError('Please fill all shipping details');
      return;
    }
    setError('');
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handlePayment = async () => {
    try {
      setLoading(true);
      setError('');

      // Create order in database
      const orderResponse = await axios.post('/api/orders', {
        productId: product._id,
        quantity,
        totalAmount: product.price * quantity,
        shippingAddress: shippingDetails
      });

      // Initialize Razorpay payment
      const paymentResponse = await axios.post('/api/payments/create-order', {
        amount: product.price * quantity
      });

      const options = {
        key: paymentResponse.data.keyId,
        amount: paymentResponse.data.amount,
        currency: paymentResponse.data.currency,
        name: 'Farmer Direct',
        description: 'Purchase from Farmer Direct',
        order_id: paymentResponse.data.orderId,
        handler: async (response) => {
          try {
            // Verify payment
            await axios.post('/api/payments/verify', {
              ...response,
              orderId: orderResponse.data._id
            });

            // Navigate to success page
            navigate('/order-confirmation', {
              state: {
                orderId: orderResponse.data._id,
                paymentId: response.razorpay_payment_id
              }
            });
          } catch (error) {
            setError('Payment verification failed. Please contact support.');
            setLoading(false);
          }
        },
        prefill: {
          name: user.name,
          email: user.email,
          contact: shippingDetails.phone
        },
        theme: {
          color: '#4CAF50'
        }
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      setError(error.response?.data?.message || 'Something went wrong');
      setLoading(false);
    }
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                name="street"
                label="Street Address"
                fullWidth
                value={shippingDetails.street}
                onChange={handleShippingDetailsChange}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="city"
                label="City"
                fullWidth
                value={shippingDetails.city}
                onChange={handleShippingDetailsChange}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="state"
                label="State"
                fullWidth
                value={shippingDetails.state}
                onChange={handleShippingDetailsChange}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="zipCode"
                label="ZIP Code"
                fullWidth
                value={shippingDetails.zipCode}
                onChange={handleShippingDetailsChange}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="phone"
                label="Phone Number"
                fullWidth
                value={shippingDetails.phone}
                onChange={handleShippingDetailsChange}
                required
              />
            </Grid>
          </Grid>
        );

      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Order Summary
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography>Product: {product.name}</Typography>
                <Typography>Quantity: {quantity}</Typography>
                <Typography>Price per unit: ₹{product.price}</Typography>
                <Typography variant="h6">
                  Total Amount: ₹{product.price * quantity}
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Shipping Address
                </Typography>
                <Typography>{shippingDetails.street}</Typography>
                <Typography>
                  {shippingDetails.city}, {shippingDetails.state} {shippingDetails.zipCode}
                </Typography>
                <Typography>Phone: {shippingDetails.phone}</Typography>
              </Grid>
            </Grid>
          </Box>
        );

      case 2:
        return (
          <Box textAlign="center">
            <Typography variant="h6" gutterBottom>
              Complete Your Payment
            </Typography>
            <Typography color="textSecondary" gutterBottom>
              Click the button below to proceed with Razorpay payment
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={handlePayment}
              disabled={loading}
              sx={{ mt: 2 }}
            >
              {loading ? <CircularProgress size={24} /> : 'Pay Now'}
            </Button>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom align="center">
          Complete Your Order
        </Typography>

        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {renderStepContent(activeStep)}

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
          {activeStep !== 0 && (
            <Button onClick={handleBack} sx={{ mr: 1 }}>
              Back
            </Button>
          )}
          {activeStep !== steps.length - 1 && (
            <Button variant="contained" onClick={handleNext}>
              Next
            </Button>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default OrderPage;
