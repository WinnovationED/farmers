import React from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  Avatar,
  Divider,
  useTheme,
  useMediaQuery,
  Paper,
  Fade,
} from '@mui/material';
import {
  Agriculture,
  LocalShipping,
  Security,
  People,
  Nature,
  Timeline,
} from '@mui/icons-material';

const AboutPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const features = [
    {
      icon: <Agriculture fontSize="large" color="primary" />,
      title: 'Direct from Farmers',
      description: 'Connect directly with local farmers and get fresh produce at fair prices.',
    },
    {
      icon: <LocalShipping fontSize="large" color="primary" />,
      title: 'Fast Delivery',
      description: 'Quick and reliable delivery service to get your products fresh and on time.',
    },
    {
      icon: <Security fontSize="large" color="primary" />,
      title: 'Secure Payments',
      description: 'Safe and secure payment options for hassle-free transactions.',
    },
    {
      icon: <People fontSize="large" color="primary" />,
      title: 'Community Driven',
      description: 'Supporting local farmers and building a sustainable farming community.',
    },
    {
      icon: <Nature fontSize="large" color="primary" />,
      title: 'Sustainable Farming',
      description: 'Promoting eco-friendly farming practices for a better future.',
    },
    {
      icon: <Timeline fontSize="large" color="primary" />,
      title: 'Market Insights',
      description: 'Real-time market trends and pricing information for informed decisions.',
    },
  ];

  const stats = [
    { value: '2000+', label: 'Farmers' },
    { value: '50,000+', label: 'Customers' },
    { value: '100,000+', label: 'Orders Delivered' },
    { value: '20+', label: 'Cities' },
  ];

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      {/* Hero Section */}
      <Box sx={{ textAlign: 'center', mb: 8 }}>
        <Fade in timeout={1000}>
          <Typography
            variant="h2"
            gutterBottom
            sx={{
              fontWeight: 'bold',
              background: 'linear-gradient(45deg, #2196F3 30%, #4CAF50 90%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Farm to Table, Simplified
          </Typography>
        </Fade>
        <Fade in timeout={1500}>
          <Typography variant="h5" color="text.secondary" sx={{ mb: 4 }}>
            Connecting farmers directly with buyers for fresher produce and fairer prices
          </Typography>
        </Fade>
      </Box>

      {/* Stats Section */}
      <Paper elevation={3} sx={{ p: 4, mb: 8, borderRadius: 4 }}>
        <Grid container spacing={4} justifyContent="center">
          {stats.map((stat, index) => (
            <Fade in timeout={1000 + (index * 200)} key={stat.label}>
              <Grid item xs={6} md={3}>
                <Box textAlign="center">
                  <Typography
                    variant="h3"
                    sx={{
                      fontWeight: 'bold',
                      color: 'primary.main',
                      mb: 1
                    }}
                  >
                    {stat.value}
                  </Typography>
                  <Typography variant="h6" color="text.secondary">
                    {stat.label}
                  </Typography>
                </Box>
              </Grid>
            </Fade>
          ))}
        </Grid>
      </Paper>

      {/* Mission Section */}
      <Box sx={{ mb: 8 }}>
        <Fade in timeout={2000}>
          <Typography variant="h4" gutterBottom textAlign="center" sx={{ mb: 4 }}>
            Our Mission
          </Typography>
        </Fade>
        <Fade in timeout={2200}>
          <Typography variant="body1" color="text.secondary" textAlign="center" sx={{ mb: 4 }}>
            We're on a mission to revolutionize the agricultural marketplace by creating a direct
            connection between farmers and consumers. Our platform empowers farmers with fair prices
            while providing consumers with fresh, high-quality produce straight from the source.
          </Typography>
        </Fade>
      </Box>

      {/* Features Section */}
      <Box sx={{ mb: 8 }}>
        <Fade in timeout={2400}>
          <Typography variant="h4" gutterBottom textAlign="center" sx={{ mb: 6 }}>
            What Makes Us Different
          </Typography>
        </Fade>
        <Grid container spacing={4}>
          {features.map((feature, index) => (
            <Grid item xs={12} sm={6} md={4} key={feature.title}>
              <Fade in timeout={2600 + (index * 200)}>
                <Card
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    transition: 'transform 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                    },
                  }}
                >
                  <CardContent>
                    <Box sx={{ textAlign: 'center', mb: 2 }}>
                      {feature.icon}
                    </Box>
                    <Typography variant="h6" gutterBottom textAlign="center">
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" textAlign="center">
                      {feature.description}
                    </Typography>
                  </CardContent>
                </Card>
              </Fade>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Team Section */}
      <Box>
        <Fade in timeout={3000}>
          <Typography variant="h4" gutterBottom textAlign="center" sx={{ mb: 6 }}>
            Our Team
          </Typography>
        </Fade>
        <Grid container spacing={4} justifyContent="center">
          {[
            { name: 'John Doe', role: 'Founder & CEO', avatar: 'J' },
            { name: 'Jane Smith', role: 'Head of Operations', avatar: 'J' },
            { name: 'Mike Johnson', role: 'Tech Lead', avatar: 'M' },
          ].map((member, index) => (
            <Grid item xs={12} sm={6} md={4} key={member.name}>
              <Fade in timeout={3200 + (index * 200)}>
                <Card
                  sx={{
                    textAlign: 'center',
                    transition: 'transform 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                    },
                  }}
                >
                  <CardContent>
                    <Avatar
                      sx={{
                        width: 100,
                        height: 100,
                        margin: '0 auto 16px',
                        bgcolor: 'primary.main',
                        fontSize: '2rem',
                      }}
                    >
                      {member.avatar}
                    </Avatar>
                    <Typography variant="h6" gutterBottom>
                      {member.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {member.role}
                    </Typography>
                  </CardContent>
                </Card>
              </Fade>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
};

export default AboutPage;
