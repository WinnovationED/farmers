import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Box,
  TextField,
  MenuItem,
  Typography,
  Autocomplete,
  Chip,
  CircularProgress,
  Fade,
  Paper,
  InputAdornment,
  Slider,
  Button,
  IconButton,
  Stack,
  useTheme,
  useMediaQuery,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Collapse,
} from '@mui/material';
import {
  Search,
  FilterList,
  LocationOn,
  Sort,
  Clear,
  ExpandMore,
  ExpandLess,
  ArrowUpward,
  ArrowDownward,
  Star,
  LocalOffer,
  LocationCity,
  PriceChange,
  Category,
} from '@mui/icons-material';
import ProductCard from '../components/ProductCard';
import { useAuth } from '../contexts/AuthContext';

const categories = [
  'All',
  'Vegetables',
  'Fruits',
  'Grains',
  'Dairy',
  'Meat',
  'Poultry',
  'Organic',
  'Others',
];

const sortOptions = [
  { value: 'newest', label: 'Newest First', icon: <ArrowUpward /> },
  { value: 'price_low', label: 'Price: Low to High', icon: <ArrowDownward /> },
  { value: 'price_high', label: 'Price: High to Low', icon: <ArrowUpward /> },
  { value: 'rating', label: 'Highest Rated', icon: <Star /> },
];

const ProductsPage = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [priceRange, setPriceRange] = useState([0, 10000]);
  const [sortBy, setSortBy] = useState('newest');
  const [locations, setLocations] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [filterSections, setFilterSections] = useState({
    category: true,
    location: true,
    price: true,
    sort: true,
  });

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:5001/api/products');
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'Failed to fetch products');
        }

        // Extract unique locations
        const uniqueLocations = [...new Set(data.map(product => product.location))];
        setLocations(uniqueLocations);

        // Apply filters and sorting
        let filteredProducts = data;

        // Category filter
        if (selectedCategory !== 'All') {
          filteredProducts = filteredProducts.filter(
            product => product.category === selectedCategory
          );
        }

        // Location filter
        if (selectedLocation) {
          filteredProducts = filteredProducts.filter(
            product => product.location === selectedLocation
          );
        }

        // Price range filter
        filteredProducts = filteredProducts.filter(
          product => 
            product.price >= priceRange[0] && 
            product.price <= priceRange[1]
        );

        // Search query
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          filteredProducts = filteredProducts.filter(
            product =>
              product.name.toLowerCase().includes(query) ||
              product.description.toLowerCase().includes(query) ||
              product.category.toLowerCase().includes(query)
          );
        }

        // Sorting
        switch (sortBy) {
          case 'price_low':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
          case 'price_high':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
          case 'rating':
            filteredProducts.sort((a, b) => (b.rating || 0) - (a.rating || 0));
            break;
          default:
            filteredProducts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }

        setProducts(filteredProducts);
        setError(null);
      } catch (err) {
        setError(err.message);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [searchQuery, selectedCategory, selectedLocation, priceRange, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedLocation(null);
    setPriceRange([0, 10000]);
    setSortBy('newest');
    setFilterSections({
      category: true,
      location: true,
      price: true,
      sort: true,
    });
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      {/* Hero Section */}
      <Box
        sx={{
          background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
          borderRadius: 2,
          p: 4,
          mb: 4,
          color: 'white',
          textAlign: 'center',
        }}
      >
        <Typography variant="h3" component="h1" gutterBottom>
          Fresh Produce Marketplace
        </Typography>
        <Typography variant="h5" sx={{ mb: 2 }}>
          Connect with local farmers and get fresh, quality produce
        </Typography>
        <Button
          variant="outlined"
          size="large"
          sx={{
            color: 'white',
            borderColor: 'white',
            '&:hover': {
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
            },
          }}
        >
          Start Shopping
        </Button>
      </Box>

      {/* Search and Filters */}
      <Paper
        elevation={3}
        sx={{
          p: 3,
          mb: 4,
          borderRadius: 2,
          background: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(0, 0, 0, 0.1)',
        }}
      >
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for products..."
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search sx={{ color: 'action.active' }} />
                  </InputAdornment>
                ),
              }}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                  },
                  '&:hover fieldset': {
                    borderColor: theme.palette.primary.main,
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: theme.palette.primary.main,
                  },
                },
              }}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <Stack direction="row" spacing={2} alignItems="center" justifyContent="flex-end">
              <Button
                color="primary"
                variant={showFilters ? 'contained' : 'outlined'}
                onClick={() => setShowFilters(!showFilters)}
                startIcon={<FilterList />}
                sx={{
                  '&.MuiButton-root': {
                    borderRadius: 2,
                    textTransform: 'none',
                  },
                }}
              >
                Filters
              </Button>
              <Button
                color="error"
                variant="outlined"
                onClick={handleResetFilters}
                startIcon={<Clear />}
                sx={{
                  '&.MuiButton-root': {
                    borderRadius: 2,
                    textTransform: 'none',
                  },
                }}
              >
                Clear All
              </Button>
            </Stack>
          </Grid>
        </Grid>

        {/* Filters Section */}
        <Collapse in={showFilters}>
          <Divider sx={{ my: 2 }} />
          <List>
            {/* Category Filter */}
            <ListItem
              button
              onClick={() => setFilterSections(prev => ({ ...prev, category: !prev.category }))}
              sx={{
                '&.MuiListItem-root': {
                  borderRadius: 1,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'action.hover',
                  },
                },
              }}
            >
              <ListItemIcon>
                <Category sx={{ color: 'action.active' }} />
              </ListItemIcon>
              <ListItemText primary="Category" />
              {filterSections.category ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={filterSections.category}>
              <Box sx={{ pl: 4, mb: 2 }}>
                <Autocomplete
                  value={selectedCategory}
                  onChange={(event, newValue) => {
                    setSelectedCategory(newValue);
                  }}
                  options={categories}
                  renderInput={(params) => (
                    <TextField {...params} label="Select Category" size="small" />
                  )}
                  sx={{ width: '100%' }}
                />
              </Box>
            </Collapse>

            {/* Location Filter */}
            <ListItem
              button
              onClick={() => setFilterSections(prev => ({ ...prev, location: !prev.location }))}
              sx={{
                '&.MuiListItem-root': {
                  borderRadius: 1,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'action.hover',
                  },
                },
              }}
            >
              <ListItemIcon>
                <LocationCity sx={{ color: 'action.active' }} />
              </ListItemIcon>
              <ListItemText primary="Location" />
              {filterSections.location ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={filterSections.location}>
              <Box sx={{ pl: 4, mb: 2 }}>
                <Autocomplete
                  value={selectedLocation}
                  onChange={(event, newValue) => {
                    setSelectedLocation(newValue);
                  }}
                  options={locations}
                  renderInput={(params) => (
                    <TextField {...params} label="Select Location" size="small" />
                  )}
                  sx={{ width: '100%' }}
                />
              </Box>
            </Collapse>

            {/* Price Filter */}
            <ListItem
              button
              onClick={() => setFilterSections(prev => ({ ...prev, price: !prev.price }))}
              sx={{
                '&.MuiListItem-root': {
                  borderRadius: 1,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'action.hover',
                  },
                },
              }}
            >
              <ListItemIcon>
                <PriceChange sx={{ color: 'action.active' }} />
              </ListItemIcon>
              <ListItemText primary="Price Range" />
              {filterSections.price ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={filterSections.price}>
              <Box sx={{ pl: 4, mb: 2 }}>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  Set your price range
                </Typography>
                <Slider
                  value={priceRange}
                  onChange={(event, newValue) => setPriceRange(newValue)}
                  valueLabelDisplay="auto"
                  min={0}
                  max={10000}
                  marks={[{ value: 0 }, { value: 10000 }]}
                  sx={{
                    '& .MuiSlider-track': {
                      color: theme.palette.primary.main,
                    },
                    '& .MuiSlider-thumb': {
                      color: theme.palette.primary.main,
                    },
                  }}
                />
              </Box>
            </Collapse>

            {/* Sort Filter */}
            <ListItem
              button
              onClick={() => setFilterSections(prev => ({ ...prev, sort: !prev.sort }))}
              sx={{
                '&.MuiListItem-root': {
                  borderRadius: 1,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'action.hover',
                  },
                },
              }}
            >
              <ListItemIcon>
                <Sort sx={{ color: 'action.active' }} />
              </ListItemIcon>
              <ListItemText primary="Sort By" />
              {filterSections.sort ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={filterSections.sort}>
              <Box sx={{ pl: 4, mb: 2 }}>
                <Autocomplete
                  value={sortOptions.find(option => option.value === sortBy)}
                  onChange={(event, newValue) => {
                    if (newValue) {
                      setSortBy(newValue.value);
                    }
                  }}
                  options={sortOptions}
                  getOptionLabel={(option) => option.label}
                  renderOption={(props, option) => (
                    <Box component="li" {...props}>
                      <ListItemIcon>
                        {option.icon}
                      </ListItemIcon>
                      <ListItemText primary={option.label} />
                    </Box>
                  )}
                  renderInput={(params) => (
                    <TextField {...params} label="Sort By" size="small" />
                  )}
                  sx={{ width: '100%' }}
                />
              </Box>
            </Collapse>
          </List>
        </Collapse>
      </Paper>

      {/* Products Grid */}
      <Grid container spacing={3}>
        {loading ? (
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress size={40} />
            </Box>
          </Grid>
        ) : error ? (
          <Grid item xs={12}>
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography color="error" variant="h6">
                {error}
              </Typography>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => window.location.reload()}
                sx={{ mt: 2 }}
              >
                Try Again
              </Button>
            </Box>
          </Grid>
        ) : products.length === 0 ? (
          <Grid item xs={12}>
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="h6" color="text.secondary">
                No products found matching your criteria
              </Typography>
              <Button
                variant="outlined"
                color="primary"
                onClick={handleResetFilters}
                sx={{ mt: 2 }}
              >
                Reset Filters
              </Button>
            </Box>
          </Grid>
        ) : (
          products.map((product) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={product._id}>
              <ProductCard product={product} />
            </Grid>
          ))
        )}
      </Grid>
    </Container>
  );
};

export default ProductsPage;
