import React, { useState, useEffect } from 'react';
import { Container, Snackbar, Alert, CircularProgress } from '@mui/material';
import PreBookingForm from '../components/PreBooking/PreBookingForm';
import { useNavigate, useParams } from 'react-router-dom';

const PreBookingPage = () => {
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [productData, setProductData] = useState(null);
  const navigate = useNavigate();
  const { productId } = useParams();

  useEffect(() => {
    fetchProductData();
  }, [productId]);

  const fetchProductData = async () => {
    try {
      const response = await fetch(`/api/products/${productId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch product details');
      }
      const data = await response.json();
      setProductData(data);
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleSuccess = (order) => {
    setNotification({
      open: true,
      message: 'Pre-booking successful! You can track your order in My Orders.',
      severity: 'success'
    });
    
    // Redirect to orders page after 2 seconds
    setTimeout(() => {
      navigate('/my-orders');
    }, 2000);
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };

  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
        <CircularProgress />
      </Container>
    );
  }

  if (error) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  if (!productData) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">Product not found</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <PreBookingForm
        product={productData}
        farmer={productData.farmer}
        onSuccess={handleSuccess}
      />
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default PreBookingPage;
